import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { useSaveCallerUserProfile } from '../hooks/useQueries';
import { toast } from 'sonner';

export default function ProfileSetupModal() {
  const [name, setName] = useState('');
  const [fatherName, setFatherName] = useState('');
  const [motherName, setMotherName] = useState('');
  const [placeOfBirth, setPlaceOfBirth] = useState('');
  const saveProfile = useSaveCallerUserProfile();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      toast.error('பெயரை உள்ளிடவும்');
      return;
    }
    if (!fatherName.trim()) {
      toast.error('தந்தை பெயரை உள்ளிடவும்');
      return;
    }
    if (!motherName.trim()) {
      toast.error('தாய் பெயரை உள்ளிடவும்');
      return;
    }
    if (!placeOfBirth.trim()) {
      toast.error('பிறந்த இடத்தை உள்ளிடவும்');
      return;
    }

    try {
      // Create empty horoscope grids (12 cells each with empty graha arrays)
      const emptyGrid = {
        cells: Array(12).fill(null).map(() => ({ grahas: [] }))
      };
      
      await saveProfile.mutateAsync({
        name: name.trim(),
        fatherName: fatherName.trim(),
        motherName: motherName.trim(),
        placeOfBirth: placeOfBirth.trim(),
        email: undefined,
        matrimonyId: undefined,
        jathagamKattam: {
          rasiKattam: emptyGrid,
          navamsamKattam: emptyGrid,
        },
      });
      toast.success('சுயவிவரம் சேமிக்கப்பட்டது');
    } catch (error) {
      toast.error('பிழை ஏற்பட்டது');
    }
  };

  return (
    <Dialog open={true}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-tamil text-2xl text-maroon">வரவேற்கிறோம்</DialogTitle>
          <DialogDescription className="font-tamil">
            தயவுசெய்து உங்கள் விவரங்களை உள்ளிடவும்
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="name" className="font-tamil">பெயர் *</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="உங்கள் பெயர்"
              className="font-tamil"
              required
            />
          </div>
          <div>
            <Label htmlFor="fatherName" className="font-tamil">தந்தை பெயர் *</Label>
            <Input
              id="fatherName"
              value={fatherName}
              onChange={(e) => setFatherName(e.target.value)}
              placeholder="தந்தை பெயர்"
              className="font-tamil"
              required
            />
          </div>
          <div>
            <Label htmlFor="motherName" className="font-tamil">தாய் பெயர் *</Label>
            <Input
              id="motherName"
              value={motherName}
              onChange={(e) => setMotherName(e.target.value)}
              placeholder="தாய் பெயர்"
              className="font-tamil"
              required
            />
          </div>
          <div>
            <Label htmlFor="placeOfBirth" className="font-tamil">பிறந்த இடம் *</Label>
            <Input
              id="placeOfBirth"
              value={placeOfBirth}
              onChange={(e) => setPlaceOfBirth(e.target.value)}
              placeholder="பிறந்த இடம்"
              className="font-tamil"
              required
            />
          </div>
          <Button type="submit" disabled={saveProfile.isPending} className="w-full bg-maroon hover:bg-maroon-dark text-white font-tamil">
            {saveProfile.isPending ? 'சேமிக்கிறது...' : 'சேமி'}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
