import { useNavigate } from '@tanstack/react-router';
import { Button } from './ui/button';

export default function Header() {
  const navigate = useNavigate();

  return (
    <header className="w-full bg-gradient-to-r from-cream via-golden to-cream border-b border-maroon-light">
      <div className="container mx-auto px-4 py-6">
        <div className="flex flex-col items-center gap-6">
          <div className="w-full flex justify-center">
            <img
              src="/assets/SKM LOGO.png"
              alt="Sree Kumaran Matrimony"
              className="w-full max-w-2xl h-auto object-contain"
            />
          </div>
          <nav className="flex flex-wrap justify-center gap-3 md:gap-4">
            <Button
              onClick={() => navigate({ to: '/' })}
              className="bg-maroon hover:bg-maroon-dark text-white rounded-full px-4 md:px-6 py-2 font-tamil text-sm md:text-base"
            >
              முகப்பு
            </Button>
            <Button
              onClick={() => navigate({ to: '/search' })}
              className="bg-maroon hover:bg-maroon-dark text-white rounded-full px-4 md:px-6 py-2 font-tamil text-sm md:text-base"
            >
              தேடல்
            </Button>
            <Button
              onClick={() => navigate({ to: '/register' })}
              className="bg-golden hover:bg-golden-dark text-maroon-dark rounded-full px-4 md:px-6 py-2 font-tamil text-sm md:text-base"
            >
              பதிவு
            </Button>
            <Button
              onClick={() => navigate({ to: '/pricing' })}
              className="bg-maroon hover:bg-maroon-dark text-white rounded-full px-4 md:px-6 py-2 font-tamil text-sm md:text-base"
            >
              விலை நிர்ணயம்
            </Button>
            <Button
              onClick={() => navigate({ to: '/about' })}
              className="bg-maroon hover:bg-maroon-dark text-white rounded-full px-4 md:px-6 py-2 font-tamil text-sm md:text-base"
            >
              எங்களை பற்றி
            </Button>
            <Button
              onClick={() => navigate({ to: '/contact' })}
              className="bg-maroon hover:bg-maroon-dark text-white rounded-full px-4 md:px-6 py-2 font-tamil text-sm md:text-base"
            >
              தொடர்பு
            </Button>
            <Button
              onClick={() => navigate({ to: '/login' })}
              className="bg-golden hover:bg-golden-dark text-maroon-dark rounded-full px-4 md:px-6 py-2 font-tamil text-sm md:text-base"
            >
              உள்நுழைய
            </Button>
          </nav>
        </div>
      </div>
    </header>
  );
}
