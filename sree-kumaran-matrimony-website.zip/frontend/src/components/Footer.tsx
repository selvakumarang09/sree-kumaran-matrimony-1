import { Heart } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="w-full bg-gradient-to-r from-maroon-dark via-maroon to-maroon-dark text-cream py-8 mt-12">
      <div className="container mx-auto px-4 text-center">
        <p className="font-tamil text-sm">
          © 2025. Built with <Heart className="inline h-4 w-4 text-golden fill-golden" /> using{' '}
          <a href="https://caffeine.ai" target="_blank" rel="noopener noreferrer" className="text-golden hover:underline">
            caffeine.ai
          </a>
        </p>
      </div>
    </footer>
  );
}
