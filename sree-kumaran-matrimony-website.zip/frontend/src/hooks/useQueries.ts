import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useActor } from './useActor';
import type { UserProfile, Profile, SearchFilter, ContactForm, ShoppingItem, MonthlyProfileStats, JathagamKattam } from '../backend';
import { Gender, MaritalStatus, Religion } from '../backend';
import { ExternalBlob } from '../backend';

// Authentication hooks
export function useRegisterUser() {
  const { actor } = useActor();

  return useMutation({
    mutationFn: async (data: { matrimonyId: string; password: string }) => {
      if (!actor) throw new Error('Actor not available');
      return actor.registerUser(data.matrimonyId, data.password);
    },
  });
}

export function useAuthenticateUser() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (data: { matrimonyId: string; password: string }) => {
      if (!actor) throw new Error('Actor not available');
      return actor.authenticateUser(data.matrimonyId, data.password);
    },
    onSuccess: () => {
      // Invalidate all queries on successful login
      queryClient.invalidateQueries();
    },
  });
}

export function useGetCallerUserProfile() {
  const { actor, isFetching: actorFetching } = useActor();

  const query = useQuery<UserProfile | null>({
    queryKey: ['currentUserProfile'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getCallerUserProfile();
    },
    enabled: !!actor && !actorFetching,
    retry: false,
  });

  return {
    ...query,
    isLoading: actorFetching || query.isLoading,
    isFetched: !!actor && query.isFetched,
  };
}

export function useSaveCallerUserProfile() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (profile: UserProfile) => {
      if (!actor) throw new Error('Actor not available');
      return actor.saveCallerUserProfile(profile);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['currentUserProfile'] });
    },
  });
}

export function useRegisterProfile() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (data: {
      name: string;
      age: bigint;
      gender: Gender;
      heightCm: bigint;
      maritalStatus: MaritalStatus;
      religion: Religion;
      caste: string;
      subCaste: string;
      education: string;
      occupation: string;
      income: bigint;
      motherTongue: string;
      fatherName: string;
      motherName: string;
      placeOfBirth: string;
      starPosition: string;
      about: string | null;
      profilePicture: ExternalBlob | null;
      jathagamKattam: JathagamKattam;
    }) => {
      if (!actor) throw new Error('Actor not available');
      const currentMonth = BigInt(new Date().getMonth() + 1);
      return actor.registerProfile(
        data.name,
        data.age,
        data.gender,
        data.heightCm,
        data.maritalStatus,
        data.religion,
        data.caste,
        data.subCaste,
        data.education,
        data.occupation,
        data.income,
        data.motherTongue,
        data.fatherName,
        data.motherName,
        data.placeOfBirth,
        data.starPosition,
        data.about,
        data.profilePicture,
        currentMonth,
        data.jathagamKattam
      );
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['callerProfile'] });
      queryClient.invalidateQueries({ queryKey: ['currentUserProfile'] });
      queryClient.invalidateQueries({ queryKey: ['adminAnalytics'] });
    },
  });
}

export function useUpdateProfile() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (data: {
      name: string;
      age: bigint;
      gender: Gender;
      heightCm: bigint;
      maritalStatus: MaritalStatus;
      religion: Religion;
      caste: string;
      subCaste: string;
      education: string;
      occupation: string;
      income: bigint;
      motherTongue: string;
      fatherName: string;
      motherName: string;
      placeOfBirth: string;
      starPosition: string;
      about: string | null;
      profilePicture: ExternalBlob | null;
      jathagamKattam: JathagamKattam;
    }) => {
      if (!actor) throw new Error('Actor not available');
      const currentMonth = BigInt(new Date().getMonth() + 1);
      return actor.updateProfile(
        data.name,
        data.age,
        data.gender,
        data.heightCm,
        data.maritalStatus,
        data.religion,
        data.caste,
        data.subCaste,
        data.education,
        data.occupation,
        data.income,
        data.motherTongue,
        data.fatherName,
        data.motherName,
        data.placeOfBirth,
        data.starPosition,
        data.about,
        data.profilePicture,
        currentMonth,
        data.jathagamKattam
      );
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['callerProfile'] });
      queryClient.invalidateQueries({ queryKey: ['currentUserProfile'] });
      queryClient.invalidateQueries({ queryKey: ['adminAnalytics'] });
    },
  });
}

export function useGetCallerProfile() {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<Profile>({
    queryKey: ['callerProfile'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getCallerProfile();
    },
    enabled: !!actor && !actorFetching,
  });
}

export function useSearchProfiles() {
  const { actor } = useActor();

  return useMutation({
    mutationFn: async (filters: SearchFilter) => {
      if (!actor) throw new Error('Actor not available');
      return actor.searchProfiles(filters);
    },
  });
}

export function useSearchProfileByMatrimonyId() {
  const { actor } = useActor();

  return useMutation({
    mutationFn: async (matrimonyId: string) => {
      if (!actor) throw new Error('Actor not available');
      return actor.searchProfileByMatrimonyId(matrimonyId);
    },
  });
}

export function useGetProfile() {
  const { actor } = useActor();

  return useMutation({
    mutationFn: async (profileId: string) => {
      if (!actor) throw new Error('Actor not available');
      return actor.getProfile(profileId);
    },
  });
}

export function useSubmitContactForm() {
  const { actor } = useActor();

  return useMutation({
    mutationFn: async (data: { name: string; email: string; message: string }) => {
      if (!actor) throw new Error('Actor not available');
      return actor.submitContactForm(data.name, data.email, data.message);
    },
  });
}

export function useIsCallerAdmin() {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<boolean>({
    queryKey: ['isAdmin'],
    queryFn: async () => {
      if (!actor) return false;
      return actor.isCallerAdmin();
    },
    enabled: !!actor && !actorFetching,
  });
}

export function useGetAllProfiles() {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<Profile[]>({
    queryKey: ['allProfiles'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getAllProfiles();
    },
    enabled: !!actor && !actorFetching,
  });
}

export function useGetAllContactForms() {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<ContactForm[]>({
    queryKey: ['allContactForms'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getAllContactForms();
    },
    enabled: !!actor && !actorFetching,
  });
}

export function useDeleteProfile() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (profileId: string) => {
      if (!actor) throw new Error('Actor not available');
      return actor.deleteProfile(profileId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['allProfiles'] });
      queryClient.invalidateQueries({ queryKey: ['adminAnalytics'] });
    },
  });
}

export function useTogglePremiumStatus() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (profileId: string) => {
      if (!actor) throw new Error('Actor not available');
      return actor.togglePremiumStatus(profileId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['allProfiles'] });
      queryClient.invalidateQueries({ queryKey: ['adminAnalytics'] });
    },
  });
}

export function useIsStripeConfigured() {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<boolean>({
    queryKey: ['isStripeConfigured'],
    queryFn: async () => {
      if (!actor) return false;
      return actor.isStripeConfigured();
    },
    enabled: !!actor && !actorFetching,
  });
}

export function useCreateCheckoutSession() {
  const { actor } = useActor();

  return useMutation({
    mutationFn: async (items: ShoppingItem[]) => {
      if (!actor) throw new Error('Actor not available');
      const baseUrl = `${window.location.protocol}//${window.location.host}`;
      const successUrl = `${baseUrl}/payment-success`;
      const cancelUrl = `${baseUrl}/payment-failure`;
      const result = await actor.createCheckoutSession(items, successUrl, cancelUrl);
      return JSON.parse(result) as { id: string; url: string };
    },
  });
}

export function useGetAdminAnalytics() {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<{
    totalUsers: bigint;
    totalProfiles: bigint;
    maleCount: bigint;
    femaleCount: bigint;
    singleCount: bigint;
    divorcedCount: bigint;
    widowedCount: bigint;
    monthlyProfiles: MonthlyProfileStats[];
    districtDistribution: [string, bigint][];
    averageIncome: bigint;
    averageAge: bigint;
  }>({
    queryKey: ['adminAnalytics'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getAdminAnalytics();
    },
    enabled: !!actor && !actorFetching,
    refetchInterval: 30000,
  });
}
