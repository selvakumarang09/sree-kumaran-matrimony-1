// Caste-Subcaste hierarchical mapping for Tamil matrimony
export const casteSubcasteMapping: Record<string, string[]> = {
  'முதலியார்': [
    'முதலியார்',
    'செங்குந்தர் / கைக்கோளர்',
    'பிள்ளை',
    'அகமுடையார்',
    'தொண்டைமண்டல வேளாளர்',
    'சைவ வேளாளர்',
    'துளுவ வேளாளர்',
    'வேளாளர்',
    'இசை வேளாளர்'
  ],
  'வன்னியர்': [
    'வன்னியர்',
    'வன்னிய கவுண்டர்',
    'படையாச்சி',
    'வன்னியகுல க்ஷத்திரியர்'
  ],
  'செட்டியார்': [
    'செட்டியார்',
    'வாணிய செட்டியார்',
    'சோழிய செட்டியார்',
    'தெலுங்கு செட்டியார்',
    'ஆயிரவைஸ்யா'
  ],
  'யாதவர்': [
    'யாதவர்',
    'கொல்லா',
    'கோனார்'
  ],
  'பிராமணர்': [
    'ஐயங்கார்',
    'ஐயர்',
    'வடமா',
    'தெலுங்கு பிராமின்',
    'பிரகச்சரணம்',
    'மார்த்தர்',
    'கன்னட பிராமின்'
  ],
  'முக்குலத்தோர் / தேவர்': [
    'தேவர் / முக்குலத்தோர்',
    'கள்ளர்',
    'அகமுடையார்',
    'முத்துராஜா / முத்தரையர்'
  ],
  'இதர ஜாதிகள்': [
    'கவுண்டர்',
    'நாயுடு',
    'நாடார்',
    'விஸ்வகர்மா',
    'கிராமணி',
    'உடையார்',
    'போயர்',
    'பார்கவகுலம்',
    'குலாலர்',
    'வன்னார்',
    'கருணீகர்',
    'ஆதி திராவிடர்',
    'அருந்ததியர்',
    'Caste No Bar'
  ]
};

// Main caste categories
export const casteCategories = [
  'முதலியார்',
  'வன்னியர்',
  'செட்டியார்',
  'யாதவர்',
  'பிராமணர்',
  'முக்குலத்தோர் / தேவர்',
  'இதர ஜாதிகள்'
];

// Get filtered subcaste options based on selected caste
export function getSubcasteOptions(selectedCaste: string): string[] {
  if (!selectedCaste || selectedCaste === 'any') {
    // Return all subcastes if no caste is selected
    return Object.values(casteSubcasteMapping).flat();
  }
  
  return casteSubcasteMapping[selectedCaste] || [];
}
