import { useNavigate } from '@tanstack/react-router';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Check, ExternalLink } from 'lucide-react';
import { SiFacebook, SiX, SiInstagram, SiYoutube } from 'react-icons/si';
import { useCreateCheckoutSession } from '../hooks/useQueries';
import { useState } from 'react';
import { toast } from 'sonner';

export default function PaymentPage() {
  const navigate = useNavigate();
  const createCheckoutSession = useCreateCheckoutSession();
  const [isProcessing, setIsProcessing] = useState(false);

  const handlePremiumPayment = async () => {
    setIsProcessing(true);
    try {
      const items = [
        {
          productName: 'பிரீமியம் திட்டம்',
          productDescription: 'உங்கள் சுயவிவரத்தை பதிவு செய்ய',
          priceInCents: BigInt(99900),
          currency: 'INR',
          quantity: BigInt(1),
        },
      ];
      const session = await createCheckoutSession.mutateAsync(items);
      
      // Open payment in new window/tab
      const paymentWindow = window.open(session.url, '_blank');
      
      if (!paymentWindow) {
        toast.error('பாப்-அப் தடுக்கப்பட்டது. உங்கள் உலாவியில் பாப்-அப்களை அனுமதிக்கவும்.');
      } else {
        toast.success('பணம் செலுத்தல் புதிய சாளரத்தில் திறக்கப்பட்டது');
      }
      
      setIsProcessing(false);
    } catch (error) {
      console.error('Payment error:', error);
      toast.error('கட்டணம் செயல்படுத்த முடியவில்லை. மீண்டும் முயற்சிக்கவும்.');
      setIsProcessing(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-cream via-white to-cream">
      {/* Payment Header */}
      <section className="py-12 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold text-maroon mb-4 font-tamil">பணம் செலுத்தல்</h1>
            <p className="text-xl text-maroon-dark font-tamil">பிரீமியம் திட்டத்திற்கு மேம்படுத்தி முழு அம்சங்களை பெறுங்கள்</p>
          </div>

          {/* Payment Options */}
          <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto mb-16">
            {/* Free Plan Section */}
            <Card className="border-2 border-maroon shadow-xl">
              <CardHeader className="bg-gradient-to-r from-maroon-light to-maroon text-white text-center py-8">
                <CardTitle className="text-3xl md:text-4xl font-tamil mb-2">இலவச திட்டம்</CardTitle>
                <CardDescription className="text-cream text-lg font-tamil">
                  சுயவிவரங்களை பார்க்கலாம்
                </CardDescription>
              </CardHeader>
              <CardContent className="p-8">
                <p className="text-maroon-dark font-tamil text-lg mb-6 text-center">
                  சுயவிவரங்களை பார்க்கலாம்
                </p>
                <Button
                  disabled
                  className="w-full bg-gray-400 text-white font-tamil text-xl py-7 rounded-lg cursor-not-allowed opacity-60"
                >
                  இலவசம்
                </Button>
              </CardContent>
            </Card>

            {/* Premium Plan Section */}
            <Card className="border-2 border-golden shadow-2xl hover:shadow-3xl transition-shadow">
              <CardHeader className="bg-gradient-to-r from-golden to-golden-dark text-maroon-dark text-center py-8">
                <CardTitle className="text-3xl md:text-4xl font-tamil mb-2">பிரீமியம் திட்டம் ₹999</CardTitle>
                <CardDescription className="text-maroon text-lg font-tamil font-semibold">
                  முழு அணுகல்
                </CardDescription>
              </CardHeader>
              <CardContent className="p-8">
                <div className="text-center mb-6">
                  <span className="text-5xl font-bold text-maroon">₹999</span>
                </div>
                <div className="mb-8 space-y-3">
                  <p className="text-maroon-dark font-tamil text-lg leading-relaxed">
                    உங்கள் சுயவிவரத்தை பதிவு செய்யலாம், முழு தேடல் வசதி, தொடர்பு விவரங்கள் பார்க்கலாம், புகைப்படம் மற்றும் ஜாதகம் பதிவேற்றம்
                  </p>
                </div>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-start font-tamil text-maroon-dark">
                    <Check className="h-5 w-5 text-golden mr-2 flex-shrink-0 mt-1" />
                    <span>உங்கள் சுயவிவரத்தை பதிவு செய்யலாம்</span>
                  </li>
                  <li className="flex items-start font-tamil text-maroon-dark">
                    <Check className="h-5 w-5 text-golden mr-2 flex-shrink-0 mt-1" />
                    <span>முழு தேடல் வசதி</span>
                  </li>
                  <li className="flex items-start font-tamil text-maroon-dark">
                    <Check className="h-5 w-5 text-golden mr-2 flex-shrink-0 mt-1" />
                    <span>தொடர்பு விவரங்களை பார்க்கலாம்</span>
                  </li>
                  <li className="flex items-start font-tamil text-maroon-dark">
                    <Check className="h-5 w-5 text-golden mr-2 flex-shrink-0 mt-1" />
                    <span>புகைப்படம் மற்றும் ஜாதகம் பதிவேற்றம்</span>
                  </li>
                </ul>

                {/* New Window Notice */}
                <div className="mb-4 p-3 bg-golden/10 border border-golden rounded-lg flex items-center gap-2">
                  <ExternalLink className="h-5 w-5 text-maroon flex-shrink-0" />
                  <p className="text-sm font-tamil text-maroon-dark">
                    பணம் செலுத்தல் புதிய சாளரத்தில் திறக்கும்
                  </p>
                </div>

                <Button
                  onClick={handlePremiumPayment}
                  disabled={isProcessing}
                  className="w-full bg-golden hover:bg-golden-dark text-maroon-dark font-tamil text-xl py-7 rounded-lg shadow-lg disabled:opacity-50 font-bold transition-all duration-300 hover:scale-105 hover:shadow-2xl"
                >
                  {isProcessing ? 'செயலாக்கப்படுகிறது...' : 'பணம் செலுத்துங்கள்'}
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer Section */}
      <footer className="py-12 px-4 bg-gradient-to-b from-cream to-white border-t-2 border-golden">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-3 gap-8">
            {/* About Section */}
            <div>
              <h3 className="text-2xl font-bold text-maroon mb-4 font-tamil">
                ஸ்ரீ குமரன் மேட்ரிமோனி
              </h3>
              <p className="text-maroon-dark font-tamil">
                நம்பகமான மற்றும் பாரம்பரிய திருமண சேவை. உங்கள் வாழ்க்கை துணையை கண்டுபிடிக்க நாங்கள் உதவுகிறோம்.
              </p>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="text-xl font-bold text-maroon mb-4 font-tamil">
                விரைவு இணைப்புகள்
              </h4>
              <ul className="space-y-2">
                <li>
                  <button
                    onClick={() => navigate({ to: '/about' })}
                    className="text-maroon-dark hover:text-maroon font-tamil transition-colors"
                  >
                    எங்களை பற்றி
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => navigate({ to: '/pricing' })}
                    className="text-maroon-dark hover:text-maroon font-tamil transition-colors"
                  >
                    விலை நிர்ணயம்
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => navigate({ to: '/contact' })}
                    className="text-maroon-dark hover:text-maroon font-tamil transition-colors"
                  >
                    தொடர்பு
                  </button>
                </li>
              </ul>
            </div>

            {/* Social Links */}
            <div>
              <h4 className="text-xl font-bold text-maroon mb-4 font-tamil">
                எங்களை பின்தொடரவும்
              </h4>
              <div className="flex gap-4">
                <a
                  href="#"
                  className="bg-maroon p-3 rounded-full hover:bg-maroon-dark transition-colors"
                  aria-label="Facebook"
                >
                  <SiFacebook className="h-5 w-5 text-golden" />
                </a>
                <a
                  href="#"
                  className="bg-maroon p-3 rounded-full hover:bg-maroon-dark transition-colors"
                  aria-label="X (Twitter)"
                >
                  <SiX className="h-5 w-5 text-golden" />
                </a>
                <a
                  href="#"
                  className="bg-maroon p-3 rounded-full hover:bg-maroon-dark transition-colors"
                  aria-label="Instagram"
                >
                  <SiInstagram className="h-5 w-5 text-golden" />
                </a>
                <a
                  href="#"
                  className="bg-maroon p-3 rounded-full hover:bg-maroon-dark transition-colors"
                  aria-label="YouTube"
                >
                  <SiYoutube className="h-5 w-5 text-golden" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

