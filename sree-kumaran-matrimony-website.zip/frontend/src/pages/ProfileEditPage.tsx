import { useState, useEffect } from 'react';
import { useNavigate } from '@tanstack/react-router';
import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { useGetCallerProfile, useUpdateProfile } from '../hooks/useQueries';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Textarea } from '../components/ui/textarea';
import { Separator } from '../components/ui/separator';
import { Checkbox } from '../components/ui/checkbox';
import { Popover, PopoverContent, PopoverTrigger } from '../components/ui/popover';
import { CreatableSelect } from '../components/CreatableSelect';
import { Gender, MaritalStatus, Religion, Graha } from '../backend';
import { ExternalBlob } from '../backend';
import { toast } from 'sonner';
import { casteCategories, getSubcasteOptions } from '../lib/casteMapping';

const tamilNaduDistricts = [
  'அரியலூர்', 'சென்னை', 'கோயம்புத்தூர்', 'கடலூர்', 'தர்மபுரி', 'திண்டுக்கல்',
  'ஈரோடு', 'கள்ளக்குறிச்சி', 'காஞ்சிபுரம்', 'கன்னியாகுமரி', 'கரூர்', 'கிருஷ்ணகிரி',
  'மதுரை', 'மயிலாடுதுறை', 'நாகப்பட்டினம்', 'நாமக்கல்', 'நீலகிரி', 'பெரம்பலூர்',
  'புதுக்கோட்டை', 'இராமநாதபுரம்', 'ரானிப்பேட்டை', 'சேலம்', 'சிவகங்கை', 'தஞ்சாவூர்',
  'தேனி', 'தூத்துக்குடி', 'திருச்சிராப்பள்ளி', 'திருநெல்வேலி', 'திருப்பூர்', 'திருப்பத்தூர்',
  'திருவண்ணாமலை', 'திருவள்ளூர்', 'திருவாரூர்', 'வேலூர்', 'விழுப்புரம்', 'விருதுநகர்'
];

const rasiList = [
  'மேஷம்', 'ரிஷபம்', 'மிதுனம்', 'கடகம்', 'சிம்மம்', 'கன்னி',
  'துலாம்', 'விருச்சிகம்', 'தனுசு', 'மகரம்', 'கும்பம்', 'மீனம்'
];

const nakshatraList = [
  'அஸ்வினி', 'பரணி', 'கார்த்திகை', 'ரோகிணி', 'மிருகசீரிடம்', 'திருவாதிரை',
  'புனர்பூசம்', 'பூசம்', 'ஆயில்யம்', 'மகம்', 'பூரம்', 'உத்திரம்',
  'அஸ்தம்', 'சித்திரை', 'சுவாதி', 'விசாகம்', 'அனுஷம்', 'கேட்டை',
  'மூலம்', 'பூராடம்', 'உத்திராடம்', 'திருவோணம்', 'அவிட்டம்', 'சதயம்',
  'பூரட்டாதி', 'உத்திரட்டாதி', 'ரேவதி'
];

const maritalStatusOptions = [
  'திருமணம் ஆகாதவர்',
  'விவாகரத்து',
  'விவாகரத்திற்காக காத்திருப்பவர்'
];

const grahaMap: Record<Graha, string> = {
  [Graha.sun]: 'சூ',
  [Graha.moon]: 'ச',
  [Graha.mars]: 'செ',
  [Graha.mercury]: 'பு',
  [Graha.jupiter]: 'கு',
  [Graha.venus]: 'சு',
  [Graha.saturn]: 'ச',
  [Graha.rahu]: 'ரா',
  [Graha.ketu]: 'கே',
  [Graha.lagna]: 'ல',
};

const grahaOptions = [
  { value: Graha.sun, label: 'சூரியன் (சூ)' },
  { value: Graha.moon, label: 'சந்திரன் (ச)' },
  { value: Graha.mars, label: 'செவ்வாய் (செ)' },
  { value: Graha.mercury, label: 'புதன் (பு)' },
  { value: Graha.jupiter, label: 'குரு (கு)' },
  { value: Graha.venus, label: 'சுக்கிரன் (சு)' },
  { value: Graha.saturn, label: 'சனி (ச)' },
  { value: Graha.rahu, label: 'ராகு (ரா)' },
  { value: Graha.ketu, label: 'கேது (கே)' },
  { value: Graha.lagna, label: 'லக்னம் (ல)' },
];

function GrahaMultiSelect({ 
  value, 
  onChange, 
  cellNumber 
}: { 
  value: Graha[]; 
  onChange: (grahas: Graha[]) => void;
  cellNumber: number;
}) {
  const [open, setOpen] = useState(false);

  const toggleGraha = (graha: Graha) => {
    if (value.includes(graha)) {
      onChange(value.filter(g => g !== graha));
    } else {
      onChange([...value, graha]);
    }
  };

  const displayText = value.length > 0 
    ? value.map(g => grahaMap[g]).join(', ')
    : '*';

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <button
          type="button"
          className="w-full h-full min-h-[60px] px-2 py-2 text-xs font-tamil border-2 border-golden bg-cream/50 hover:bg-cream/70 rounded flex items-center justify-center text-center transition-colors"
        >
          <span className="text-maroon-dark font-medium leading-tight break-words">
            {displayText}
          </span>
        </button>
      </PopoverTrigger>
      <PopoverContent className="w-56 p-3" align="start">
        <div className="space-y-2">
          <p className="text-sm font-tamil font-semibold text-maroon mb-2">கிரகங்களை தேர்ந்தெடுக்கவும்:</p>
          {grahaOptions.map((option) => (
            <div key={option.value} className="flex items-center space-x-2">
              <Checkbox
                id={`${cellNumber}-${option.value}`}
                checked={value.includes(option.value)}
                onCheckedChange={() => toggleGraha(option.value)}
              />
              <label
                htmlFor={`${cellNumber}-${option.value}`}
                className="text-sm font-tamil cursor-pointer flex-1"
              >
                {option.label}
              </label>
            </div>
          ))}
        </div>
      </PopoverContent>
    </Popover>
  );
}

export default function ProfileEditPage() {
  const navigate = useNavigate();
  const { identity, login } = useInternetIdentity();
  const { data: currentProfile, isLoading } = useGetCallerProfile();
  const updateProfile = useUpdateProfile();

  const [formData, setFormData] = useState({
    name: '',
    age: '',
    gender: '',
    dateOfBirth: '',
    heightCm: '',
    weight: '',
    complexion: '',
    district: '',
    city: '',
    nativePlace: '',
    caste: '',
    subCaste: '',
    gothram: '',
    rasi: '',
    nakshatra: '',
    birthTime: '',
    placeOfBirth: '',
    education: '',
    occupation: '',
    monthlyIncome: '',
    fatherName: '',
    mobileNumber: '',
    brothers: '',
    sisters: '',
    maritalStatus: '',
    expectations: '',
    religion: '',
    motherTongue: '',
  });

  const [rasiKattam, setRasiKattam] = useState<Graha[][]>(Array(16).fill(null).map(() => []));
  const [navamsaKattam, setNavamsaKattam] = useState<Graha[][]>(Array(16).fill(null).map(() => []));
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string>('');

  // Dynamic subcaste options based on selected caste
  const [subCasteOptions, setSubCasteOptions] = useState<string[]>([]);

  // Update subcaste options when caste changes
  useEffect(() => {
    const options = getSubcasteOptions(formData.caste);
    setSubCasteOptions(options);
    
    // Clear subcaste if it's not in the new filtered list
    if (formData.subCaste && !options.includes(formData.subCaste)) {
      setFormData(prev => ({ ...prev, subCaste: '' }));
    }
  }, [formData.caste]);

  useEffect(() => {
    if (!identity) {
      toast.error('முதலில் உள்நுழையவும்');
      login();
      return;
    }
  }, [identity, login]);

  useEffect(() => {
    if (currentProfile) {
      let horoscopeData: { rasi?: string; nakshatra?: string; birthTime?: string } = {};
      try {
        horoscopeData = JSON.parse(currentProfile.starPosition);
      } catch (e) {
        horoscopeData = { rasi: currentProfile.starPosition };
      }

      const getMaritalStatusTamil = (status: string) => {
        switch (status) {
          case 'single': return 'திருமணம் ஆகாதவர்';
          case 'divorced': return 'விவாகரத்து';
          case 'widowed': return 'விவாகரத்திற்காக காத்திருப்பவர்';
          default: return status;
        }
      };

      setFormData({
        name: currentProfile.name,
        age: Number(currentProfile.age).toString(),
        gender: currentProfile.gender,
        dateOfBirth: '',
        heightCm: Number(currentProfile.heightCm).toString(),
        weight: '',
        complexion: '',
        district: currentProfile.placeOfBirth,
        city: '',
        nativePlace: '',
        caste: currentProfile.caste,
        subCaste: currentProfile.subCaste || '',
        gothram: '',
        rasi: horoscopeData.rasi || '',
        nakshatra: horoscopeData.nakshatra || '',
        birthTime: horoscopeData.birthTime || '',
        placeOfBirth: currentProfile.placeOfBirth,
        education: currentProfile.education,
        occupation: currentProfile.occupation,
        monthlyIncome: Number(currentProfile.income).toString(),
        fatherName: currentProfile.fatherName,
        mobileNumber: '',
        brothers: '',
        sisters: '',
        maritalStatus: getMaritalStatusTamil(currentProfile.maritalStatus),
        expectations: currentProfile.about || '',
        religion: currentProfile.religion,
        motherTongue: currentProfile.motherTongue,
      });

      if (currentProfile.jathagamKattam) {
        const rasiCells = currentProfile.jathagamKattam.rasiKattam.cells.map(cell => cell.grahas);
        const navamsaCells = currentProfile.jathagamKattam.navamsamKattam.cells.map(cell => cell.grahas);
        
        // Pad to 16 cells if needed
        while (rasiCells.length < 16) rasiCells.push([]);
        while (navamsaCells.length < 16) navamsaCells.push([]);
        
        setRasiKattam(rasiCells);
        setNavamsaKattam(navamsaCells);
      }

      if (currentProfile.profilePicture) {
        setPhotoPreview(currentProfile.profilePicture.getDirectURL());
      }
    }
  }, [currentProfile]);

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        toast.error('படத்தை மட்டும் பதிவேற்றவும்');
        return;
      }
      setPhotoFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhotoPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!identity) {
      toast.error('முதலில் உள்நுழையவும்');
      login();
      return;
    }

    if (!formData.name || !formData.age || !formData.gender) {
      toast.error('அனைத்து கட்டாய புலங்களையும் நிரப்பவும்');
      return;
    }

    if (parseInt(formData.age) < 18) {
      toast.error('வயது குறைந்தது 18 ஆக இருக்க வேண்டும்');
      return;
    }

    try {
      let profilePictureBlob: ExternalBlob | null = null;
      
      if (photoFile) {
        const arrayBuffer = await photoFile.arrayBuffer();
        const uint8Array = new Uint8Array(arrayBuffer);
        profilePictureBlob = ExternalBlob.fromBytes(uint8Array);
      } else if (currentProfile?.profilePicture) {
        profilePictureBlob = currentProfile.profilePicture;
      }

      const jathagamKattam = {
        rasiKattam: {
          cells: rasiKattam.map(grahas => ({ grahas }))
        },
        navamsamKattam: {
          cells: navamsaKattam.map(grahas => ({ grahas }))
        }
      };

      const horoscopeData = {
        rasi: formData.rasi,
        nakshatra: formData.nakshatra,
        birthTime: formData.birthTime,
      };
      const starPosition = JSON.stringify(horoscopeData);

      let maritalStatusEnum: MaritalStatus = MaritalStatus.single;
      if (formData.maritalStatus === 'விவாகரத்து') {
        maritalStatusEnum = MaritalStatus.divorced;
      } else if (formData.maritalStatus === 'விவாகரத்திற்காக காத்திருப்பவர்') {
        maritalStatusEnum = MaritalStatus.widowed;
      }

      await updateProfile.mutateAsync({
        name: formData.name,
        age: BigInt(formData.age),
        gender: formData.gender as Gender,
        heightCm: BigInt(formData.heightCm || 0),
        maritalStatus: maritalStatusEnum,
        religion: (formData.religion || 'hindu') as Religion,
        caste: formData.caste || '',
        subCaste: formData.subCaste || '',
        education: formData.education || '',
        occupation: formData.occupation || '',
        income: BigInt(formData.monthlyIncome || 0),
        motherTongue: formData.motherTongue || 'தமிழ்',
        fatherName: formData.fatherName,
        motherName: currentProfile?.motherName || '',
        placeOfBirth: formData.placeOfBirth || '',
        starPosition: starPosition,
        about: formData.expectations || null,
        profilePicture: profilePictureBlob,
        jathagamKattam: jathagamKattam,
      });

      toast.success('சுயவிவரம் வெற்றிகரமாக புதுப்பிக்கப்பட்டது!');
      navigate({ to: '/search' });
    } catch (error: any) {
      console.error('Update error:', error);
      toast.error(error.message || 'புதுப்பிப்பு தோல்வியடைந்தது');
    }
  };

  const gridLayout = [
    [0, 1, 2, 3],
    [4, -1, -1, 7],
    [8, -1, -1, 11],
    [12, 13, 14, 15]
  ];

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-cream via-white to-cream flex items-center justify-center">
        <p className="text-2xl text-maroon font-tamil">ஏற்றுகிறது...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-cream via-white to-cream py-12 px-4">
      <div className="container mx-auto max-w-5xl">
        <Card className="border-2 border-golden shadow-2xl">
          <CardHeader className="bg-gradient-to-r from-maroon via-maroon-dark to-maroon text-white">
            <CardTitle className="text-4xl font-tamil text-center font-bold">சுயவிவரம் திருத்து</CardTitle>
          </CardHeader>
          <CardContent className="p-8">
            <form onSubmit={handleSubmit} className="space-y-8">
              {/* Personal Information */}
              <div className="space-y-4">
                <h3 className="text-2xl font-tamil font-semibold text-maroon border-b-2 border-golden pb-2">
                  தனிப்பட்ட தகவல்
                </h3>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="name" className="font-tamil text-maroon-dark font-medium">பெயர் *</Label>
                    <Input
                      id="name"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="font-tamil border-maroon-light focus:border-golden"
                      placeholder="உங்கள் பெயரை உள்ளிடவும்"
                    />
                  </div>
                  <div>
                    <Label htmlFor="age" className="font-tamil text-maroon-dark font-medium">வயது *</Label>
                    <Input
                      id="age"
                      type="number"
                      required
                      min="18"
                      value={formData.age}
                      onChange={(e) => setFormData({ ...formData, age: e.target.value })}
                      className="font-tamil border-maroon-light focus:border-golden"
                      placeholder="வயது"
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="gender" className="font-tamil text-maroon-dark font-medium">பாலினம் *</Label>
                    <Select value={formData.gender} onValueChange={(value) => setFormData({ ...formData, gender: value })}>
                      <SelectTrigger id="gender" className="font-tamil border-maroon-light">
                        <SelectValue placeholder="தேர்ந்தெடுக்கவும்" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="male" className="font-tamil">ஆண்</SelectItem>
                        <SelectItem value="female" className="font-tamil">பெண்</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="heightCm" className="font-tamil text-maroon-dark font-medium">உயரம் (செ.மீ) *</Label>
                    <Input
                      id="heightCm"
                      type="number"
                      required
                      value={formData.heightCm}
                      onChange={(e) => setFormData({ ...formData, heightCm: e.target.value })}
                      className="font-tamil border-maroon-light focus:border-golden"
                      placeholder="உயரம்"
                    />
                  </div>
                </div>
              </div>

              <Separator className="bg-golden" />

              {/* Location Information */}
              <div className="space-y-4">
                <h3 className="text-2xl font-tamil font-semibold text-maroon border-b-2 border-golden pb-2">
                  இடத் தகவல்
                </h3>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="district" className="font-tamil text-maroon-dark font-medium">மாவட்டத்தை தேர்ந்தெடுக்கவும் *</Label>
                    <CreatableSelect
                      id="district"
                      value={formData.district}
                      onChange={(value) => setFormData({ ...formData, district: value })}
                      options={tamilNaduDistricts}
                      placeholder="மாவட்டத்தை தேர்ந்தெடுக்கவும்"
                    />
                  </div>
                  <div>
                    <Label htmlFor="placeOfBirth" className="font-tamil text-maroon-dark font-medium">பிறந்த இடம் *</Label>
                    <Input
                      id="placeOfBirth"
                      required
                      value={formData.placeOfBirth}
                      onChange={(e) => setFormData({ ...formData, placeOfBirth: e.target.value })}
                      className="font-tamil border-maroon-light focus:border-golden"
                      placeholder="பிறந்த இடம்"
                    />
                  </div>
                </div>
              </div>

              <Separator className="bg-golden" />

              {/* Caste and Horoscope */}
              <div className="space-y-4">
                <h3 className="text-2xl font-tamil font-semibold text-maroon border-b-2 border-golden pb-2">
                  ஜாதி மற்றும் ஜாதக தகவல்
                </h3>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="caste" className="font-tamil text-maroon-dark font-medium">ஜாதி *</Label>
                    <CreatableSelect
                      id="caste"
                      value={formData.caste}
                      onChange={(value) => setFormData({ ...formData, caste: value })}
                      options={casteCategories}
                      placeholder="ஜாதியை தேர்ந்தெடுக்கவும்"
                    />
                  </div>
                  <div>
                    <Label htmlFor="subCaste" className="font-tamil text-maroon-dark font-medium">துணை ஜாதி</Label>
                    <CreatableSelect
                      id="subCaste"
                      value={formData.subCaste}
                      onChange={(value) => setFormData({ ...formData, subCaste: value })}
                      options={subCasteOptions}
                      placeholder="துணை ஜாதியை தேர்ந்தெடுக்கவும்"
                      disabled={!formData.caste}
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="rasi" className="font-tamil text-maroon-dark font-medium">ராசி *</Label>
                    <CreatableSelect
                      id="rasi"
                      value={formData.rasi}
                      onChange={(value) => setFormData({ ...formData, rasi: value })}
                      options={rasiList}
                      placeholder="ராசியை தேர்ந்தெடுக்கவும்"
                    />
                  </div>
                  <div>
                    <Label htmlFor="nakshatra" className="font-tamil text-maroon-dark font-medium">நட்சத்திரம் *</Label>
                    <CreatableSelect
                      id="nakshatra"
                      value={formData.nakshatra}
                      onChange={(value) => setFormData({ ...formData, nakshatra: value })}
                      options={nakshatraList}
                      placeholder="நட்சத்திரத்தை தேர்ந்தெடுக்கவும்"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="birthTime" className="font-tamil text-maroon-dark font-medium">பிறந்த நேரம் *</Label>
                  <Input
                    id="birthTime"
                    required
                    value={formData.birthTime}
                    onChange={(e) => setFormData({ ...formData, birthTime: e.target.value })}
                    className="font-tamil border-maroon-light focus:border-golden"
                    placeholder="எ.கா: காலை 10:30 அல்லது 10:30 AM"
                  />
                </div>
              </div>

              <Separator className="bg-golden" />

              {/* Educational and Professional */}
              <div className="space-y-4">
                <h3 className="text-2xl font-tamil font-semibold text-maroon border-b-2 border-golden pb-2">
                  கல்வி மற்றும் தொழில் தகவல்
                </h3>
                <div className="grid md:grid-cols-3 gap-6">
                  <div>
                    <Label htmlFor="education" className="font-tamil text-maroon-dark font-medium">கல்வித் தகுதி *</Label>
                    <Input
                      id="education"
                      required
                      value={formData.education}
                      onChange={(e) => setFormData({ ...formData, education: e.target.value })}
                      className="font-tamil border-maroon-light focus:border-golden"
                      placeholder="கல்வித் தகுதி"
                    />
                  </div>
                  <div>
                    <Label htmlFor="occupation" className="font-tamil text-maroon-dark font-medium">தொழில் *</Label>
                    <Input
                      id="occupation"
                      required
                      value={formData.occupation}
                      onChange={(e) => setFormData({ ...formData, occupation: e.target.value })}
                      className="font-tamil border-maroon-light focus:border-golden"
                      placeholder="தொழில்"
                    />
                  </div>
                  <div>
                    <Label htmlFor="monthlyIncome" className="font-tamil text-maroon-dark font-medium">மாத வருமானம் (₹)</Label>
                    <Input
                      id="monthlyIncome"
                      type="number"
                      value={formData.monthlyIncome}
                      onChange={(e) => setFormData({ ...formData, monthlyIncome: e.target.value })}
                      className="font-tamil border-maroon-light focus:border-golden"
                      placeholder="மாத வருமானம்"
                    />
                  </div>
                </div>
              </div>

              <Separator className="bg-golden" />

              {/* Marriage Status */}
              <div className="space-y-4">
                <h3 className="text-2xl font-tamil font-semibold text-maroon border-b-2 border-golden pb-2">
                  திருமண நிலை
                </h3>
                <div>
                  <Label htmlFor="maritalStatus" className="font-tamil text-maroon-dark font-medium">திருமண நிலை *</Label>
                  <CreatableSelect
                    id="maritalStatus"
                    value={formData.maritalStatus}
                    onChange={(value) => setFormData({ ...formData, maritalStatus: value })}
                    options={maritalStatusOptions}
                    placeholder="திருமண நிலையை தேர்ந்தெடுக்கவும்"
                  />
                </div>
              </div>

              <Separator className="bg-golden" />

              {/* Horoscope Grids - 4x4 with merged center */}
              <div className="space-y-6">
                <h3 className="text-2xl font-tamil font-semibold text-maroon border-b-2 border-golden pb-2">
                  ஜாதகம் கட்டம்
                </h3>
                
                <div className="grid lg:grid-cols-2 gap-8">
                  <div className="space-y-3">
                    <h4 className="text-xl font-tamil font-semibold text-maroon-dark text-center bg-gradient-to-r from-golden/20 to-transparent py-2 rounded">
                      ராசி கட்டம்
                    </h4>
                    <div className="grid grid-cols-4 gap-1 border-[3px] border-[#22c55e] p-3 rounded-lg bg-gradient-to-br from-cream/80 to-amber-50/60 shadow-lg">
                      {gridLayout.map((row, rowIndex) => (
                        row.map((cellIndex, colIndex) => {
                          if (rowIndex === 1 && colIndex === 1) {
                            return (
                              <div key={`${rowIndex}-${colIndex}`} className="col-span-2 row-span-2 border-2 border-maroon bg-cream/50 rounded flex items-center justify-center">
                                <span className="text-golden text-2xl font-tamil font-bold">ராசி</span>
                              </div>
                            );
                          }
                          if (cellIndex === -1) {
                            return null;
                          }
                          return (
                            <div key={`${rowIndex}-${colIndex}`} className="aspect-square">
                              <GrahaMultiSelect
                                value={rasiKattam[cellIndex]}
                                onChange={(grahas) => {
                                  const newKattam = [...rasiKattam];
                                  newKattam[cellIndex] = grahas;
                                  setRasiKattam(newKattam);
                                }}
                                cellNumber={cellIndex + 1}
                              />
                            </div>
                          );
                        })
                      ))}
                    </div>
                  </div>

                  <div className="space-y-3">
                    <h4 className="text-xl font-tamil font-semibold text-maroon-dark text-center bg-gradient-to-r from-golden/20 to-transparent py-2 rounded">
                      நவாம்சம் கட்டம்
                    </h4>
                    <div className="grid grid-cols-4 gap-1 border-[3px] border-[#22c55e] p-3 rounded-lg bg-gradient-to-br from-cream/80 to-amber-50/60 shadow-lg">
                      {gridLayout.map((row, rowIndex) => (
                        row.map((cellIndex, colIndex) => {
                          if (rowIndex === 1 && colIndex === 1) {
                            return (
                              <div key={`${rowIndex}-${colIndex}`} className="col-span-2 row-span-2 border-2 border-maroon bg-cream/50 rounded flex items-center justify-center">
                                <span className="text-golden text-2xl font-tamil font-bold">நவாம்சம்</span>
                              </div>
                            );
                          }
                          if (cellIndex === -1) {
                            return null;
                          }
                          return (
                            <div key={`${rowIndex}-${colIndex}`} className="aspect-square">
                              <GrahaMultiSelect
                                value={navamsaKattam[cellIndex]}
                                onChange={(grahas) => {
                                  const newKattam = [...navamsaKattam];
                                  newKattam[cellIndex] = grahas;
                                  setNavamsaKattam(newKattam);
                                }}
                                cellNumber={cellIndex + 1}
                              />
                            </div>
                          );
                        })
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              <Separator className="bg-golden" />

              {/* Life Partner Expectations */}
              <div className="space-y-4">
                <h3 className="text-2xl font-tamil font-semibold text-maroon border-b-2 border-golden pb-2">
                  வாழ்க்கைத் துணை எதிர்பார்ப்புகள்
                </h3>
                <div>
                  <Label htmlFor="expectations" className="font-tamil text-maroon-dark font-medium">எதிர்பார்ப்புகள்</Label>
                  <Textarea
                    id="expectations"
                    rows={5}
                    value={formData.expectations}
                    onChange={(e) => setFormData({ ...formData, expectations: e.target.value })}
                    className="font-tamil border-maroon-light focus:border-golden"
                    placeholder="உங்கள் வாழ்க்கைத் துணை பற்றிய எதிர்பார்ப்புகளை விவரிக்கவும்..."
                  />
                </div>
              </div>

              <Separator className="bg-golden" />

              {/* File Upload Section */}
              <div className="space-y-4">
                <h3 className="text-2xl font-tamil font-semibold text-maroon border-b-2 border-golden pb-2">
                  புகைப்படம்
                </h3>
                <div>
                  <Label htmlFor="photo" className="font-tamil text-maroon-dark font-medium">புகைப்படம்</Label>
                  <Input
                    id="photo"
                    type="file"
                    accept="image/*"
                    onChange={handlePhotoChange}
                    className="font-tamil border-maroon-light focus:border-golden"
                  />
                  {photoPreview && (
                    <div className="mt-3">
                      <img
                        src={photoPreview}
                        alt="Preview"
                        className="w-32 h-32 object-cover rounded-lg border-2 border-golden"
                      />
                    </div>
                  )}
                </div>
              </div>

              <Separator className="bg-golden" />

              {/* Submit Button */}
              <div className="flex justify-center gap-4 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => navigate({ to: '/search' })}
                  className="px-8 font-tamil text-lg py-6 border-maroon text-maroon hover:bg-maroon/10"
                >
                  ரத்து செய்
                </Button>
                <Button
                  type="submit"
                  disabled={updateProfile.isPending}
                  className="px-16 bg-gradient-to-r from-maroon to-maroon-dark hover:from-maroon-dark hover:to-maroon text-white font-tamil text-xl py-6 rounded-full shadow-lg hover:shadow-xl transition-all duration-300"
                >
                  {updateProfile.isPending ? 'புதுப்பிக்கிறது...' : 'புதுப்பிக்கவும்'}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
