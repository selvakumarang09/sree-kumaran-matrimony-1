import { useEffect, useState } from 'react';
import { useParams, useNavigate } from '@tanstack/react-router';
import { useGetProfile, useGetCallerProfile } from '../hooks/useQueries';
import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Button } from '../components/ui/button';
import { Crown, User, GraduationCap, Heart, Users, Star, Edit, MapPin, FileText } from 'lucide-react';
import type { Profile, Graha } from '../backend';

const grahaMap: Record<Graha, string> = {
  sun: 'சூ',
  moon: 'ச',
  mars: 'செ',
  mercury: 'பு',
  jupiter: 'கு',
  venus: 'சு',
  saturn: 'ச',
  rahu: 'ரா',
  ketu: 'கே',
  lagna: 'ல',
};

export default function ProfileViewPage() {
  const { profileId } = useParams({ from: '/profile/$profileId' });
  const navigate = useNavigate();
  const { identity } = useInternetIdentity();
  const getProfile = useGetProfile();
  const { data: callerProfile } = useGetCallerProfile();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [imageUrl, setImageUrl] = useState<string | null>(null);

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const result = await getProfile.mutateAsync(profileId);
        setProfile(result);
        
        if (result?.profilePicture) {
          setImageUrl(result.profilePicture.getDirectURL());
        }
      } catch (error) {
        console.error('Error fetching profile:', error);
      }
    };
    fetchProfile();
  }, [profileId]);

  if (getProfile.isPending) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-cream via-white to-cream flex items-center justify-center">
        <p className="text-2xl text-maroon font-tamil">ஏற்றுகிறது...</p>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-cream via-white to-cream flex items-center justify-center">
        <div className="text-center">
          <p className="text-2xl text-maroon font-tamil mb-4">சுயவிவரம் கிடைக்கவில்லை</p>
          <Button onClick={() => navigate({ to: '/search' })} className="bg-maroon hover:bg-maroon-dark text-white font-tamil">
            தேடலுக்கு திரும்பு
          </Button>
        </div>
      </div>
    );
  }

  const getGenderLabel = (gender: string) => {
    return gender === 'male' ? 'ஆண்' : 'பெண்';
  };

  const getMaritalStatusLabel = (status: string) => {
    switch (status) {
      case 'single': return 'திருமணம் ஆகாதவர்';
      case 'divorced': return 'விவாகரத்து';
      case 'widowed': return 'விவாகரத்திற்காக காத்திருப்பவர்';
      default: return status;
    }
  };

  const getReligionLabel = (religion: string) => {
    switch (religion) {
      case 'hindu': return 'இந்து';
      case 'christian': return 'கிறிஸ்தவர்';
      case 'muslim': return 'முஸ்லிம்';
      case 'jain': return 'ஜைன';
      case 'sikh': return 'சீக்கியர்';
      case 'other': return 'மற்றவை';
      default: return religion;
    }
  };

  let horoscopeData: { rasi?: string; nakshatra?: string; birthTime?: string; caste?: string; subCaste?: string; gothram?: string } = {};
  try {
    horoscopeData = JSON.parse(profile.starPosition);
  } catch (e) {
    horoscopeData = { rasi: profile.starPosition };
  }

  const isOwnProfile = callerProfile?.id === profile.id;

  // 4x4 Grid layout with merged center cells
  const gridLayout = [
    [0, 1, 2, 3],
    [4, -1, -1, 7],
    [8, -1, -1, 11],
    [12, 13, 14, 15]
  ];

  const renderHoroscopeGrid = (cells: Array<{ grahas: Graha[] }>, title: string, label: string) => {
    // Pad to 16 cells if needed
    const paddedCells = [...cells];
    while (paddedCells.length < 16) paddedCells.push({ grahas: [] });

    return (
      <div className="space-y-3">
        <h4 className="text-lg font-tamil font-semibold text-maroon-dark text-center bg-gradient-to-r from-golden/20 to-transparent py-2 rounded">
          {title}
        </h4>
        <div className="grid grid-cols-4 gap-1 border-[3px] border-[#22c55e] p-3 rounded-lg bg-gradient-to-br from-cream/80 to-amber-50/60 shadow-lg">
          {gridLayout.map((row, rowIndex) => (
            row.map((cellIndex, colIndex) => {
              // Merged center cell (spans 2x2)
              if (rowIndex === 1 && colIndex === 1) {
                return (
                  <div 
                    key={`${rowIndex}-${colIndex}`} 
                    className="col-span-2 row-span-2 border-2 border-maroon bg-cream/50 rounded flex items-center justify-center p-2"
                  >
                    <span className="text-golden text-2xl font-tamil font-bold">
                      {label}
                    </span>
                  </div>
                );
              }
              // Skip cells that are part of the merged center
              if (cellIndex === -1) {
                return null;
              }
              const grahas = paddedCells[cellIndex]?.grahas || [];
              const displayText = grahas.length > 0 
                ? grahas.map(g => grahaMap[g]).join(', ')
                : '*';
              return (
                <div 
                  key={`${rowIndex}-${colIndex}`} 
                  className="aspect-square border-2 border-golden bg-cream/50 rounded flex items-center justify-center p-1"
                >
                  <span className="text-maroon-dark font-tamil font-medium text-xs text-center leading-tight break-words">
                    {displayText}
                  </span>
                </div>
              );
            })
          ))}
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-cream via-white to-cream py-8 md:py-12 px-4">
      <div className="container mx-auto max-w-5xl">
        <Card className="border-2 border-golden shadow-2xl">
          <CardHeader className="bg-gradient-to-r from-maroon to-maroon-dark text-white">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div>
                <CardTitle className="text-3xl md:text-4xl font-tamil mb-2">{profile.name}</CardTitle>
                <p className="text-cream text-lg font-tamil">அடையாள எண்: {profile.id}</p>
              </div>
              {profile.premiumMember && (
                <Badge className="bg-golden text-maroon-dark text-base md:text-lg px-4 py-2">
                  <Crown className="h-5 w-5 mr-2" />
                  பிரீமியம் உறுப்பினர்
                </Badge>
              )}
            </div>
          </CardHeader>
          <CardContent className="p-6 md:p-8">
            <div className="flex flex-col md:flex-row gap-8 mb-8">
              <div className="flex justify-center md:justify-start">
                <div className="w-48 h-48 md:w-56 md:h-56 bg-gradient-to-br from-golden to-maroon rounded-lg flex items-center justify-center overflow-hidden shadow-lg">
                  {imageUrl ? (
                    <img src={imageUrl} alt={profile.name} className="w-full h-full object-cover" />
                  ) : (
                    <User className="h-24 w-24 md:h-32 md:w-32 text-white" />
                  )}
                </div>
              </div>

              <div className="flex-1 space-y-4">
                <div className="bg-cream p-4 rounded-lg border border-golden">
                  <h3 className="font-bold text-maroon text-xl mb-3 font-tamil flex items-center">
                    <User className="h-5 w-5 mr-2" />
                    அடிப்படை தகவல்
                  </h3>
                  <div className="grid md:grid-cols-2 gap-3 font-tamil text-maroon-dark">
                    <p><strong>பெயர்:</strong> {profile.name}</p>
                    <p><strong>வயது:</strong> {Number(profile.age)} வருடங்கள்</p>
                    <p><strong>பாலினம்:</strong> {getGenderLabel(profile.gender)}</p>
                    <p><strong>உயரம்:</strong> {Number(profile.heightCm)} செ.மீ</p>
                    <p><strong>திருமண நிலை:</strong> {getMaritalStatusLabel(profile.maritalStatus)}</p>
                    <p><strong>நிறம்:</strong> {profile.motherTongue}</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-6 mb-6">
              <div className="bg-cream p-5 rounded-lg border border-golden">
                <h3 className="font-bold text-maroon text-xl mb-3 font-tamil flex items-center">
                  <Star className="h-5 w-5 mr-2" />
                  ஜாதக தகவல்
                </h3>
                <div className="space-y-2 font-tamil text-maroon-dark">
                  <p><strong>மதம்:</strong> {getReligionLabel(profile.religion)}</p>
                  <p><strong>ஜாதி:</strong> {profile.caste}</p>
                  {horoscopeData.subCaste && <p><strong>துணை ஜாதி:</strong> {horoscopeData.subCaste}</p>}
                  {horoscopeData.gothram && <p><strong>கோத்திரம்:</strong> {horoscopeData.gothram}</p>}
                  {horoscopeData.rasi && <p><strong>ராசி:</strong> {horoscopeData.rasi}</p>}
                  {horoscopeData.nakshatra && <p><strong>நட்சத்திரம்:</strong> {horoscopeData.nakshatra}</p>}
                  {horoscopeData.birthTime && <p><strong>பிறந்த நேரம்:</strong> {horoscopeData.birthTime}</p>}
                  <p><strong>பிறந்த இடம்:</strong> {profile.placeOfBirth}</p>
                </div>
              </div>

              <div className="bg-cream p-5 rounded-lg border border-golden">
                <h3 className="font-bold text-maroon text-xl mb-3 font-tamil flex items-center">
                  <GraduationCap className="h-5 w-5 mr-2" />
                  கல்வி மற்றும் தொழில்
                </h3>
                <div className="space-y-2 font-tamil text-maroon-dark">
                  <p><strong>கல்வித் தகுதி:</strong> {profile.education}</p>
                  <p><strong>தொழில்:</strong> {profile.occupation}</p>
                  <p><strong>மாத வருமானம்:</strong> ₹{Number(profile.income).toLocaleString('en-IN')}</p>
                </div>
              </div>

              <div className="bg-cream p-5 rounded-lg border border-golden">
                <h3 className="font-bold text-maroon text-xl mb-3 font-tamil flex items-center">
                  <MapPin className="h-5 w-5 mr-2" />
                  இடம் தகவல்
                </h3>
                <div className="space-y-2 font-tamil text-maroon-dark">
                  <p><strong>மாவட்டம்:</strong> {profile.placeOfBirth}</p>
                  <p><strong>சொந்த ஊர்:</strong> {profile.placeOfBirth}</p>
                </div>
              </div>

              <div className="bg-cream p-5 rounded-lg border border-golden">
                <h3 className="font-bold text-maroon text-xl mb-3 font-tamil flex items-center">
                  <Users className="h-5 w-5 mr-2" />
                  குடும்ப தகவல்
                </h3>
                <div className="space-y-2 font-tamil text-maroon-dark">
                  <p><strong>தந்தை/உறவினர் பெயர்:</strong> {profile.fatherName}</p>
                  <p><strong>தாய் பெயர்:</strong> {profile.motherName}</p>
                </div>
              </div>
            </div>

            {profile.about && (
              <div className="bg-cream p-5 rounded-lg border border-golden mb-6">
                <h3 className="font-bold text-maroon text-xl mb-3 font-tamil flex items-center">
                  <Heart className="h-5 w-5 mr-2" />
                  எதிர்பார்ப்புகள்
                </h3>
                <p className="font-tamil text-maroon-dark text-justify leading-relaxed">{profile.about}</p>
              </div>
            )}

            {/* Profile Picture and Horoscope Attachment Section */}
            <div className="grid md:grid-cols-2 gap-6 mb-6">
              {imageUrl && (
                <div className="bg-cream p-5 rounded-lg border border-golden">
                  <h3 className="font-bold text-maroon text-xl mb-3 font-tamil flex items-center">
                    🖼️ புகைப்படம்
                  </h3>
                  <div className="w-full h-64 bg-gradient-to-br from-golden/20 to-maroon/10 rounded-lg flex items-center justify-center overflow-hidden">
                    <img src={imageUrl} alt={profile.name} className="w-full h-full object-contain" />
                  </div>
                </div>
              )}
              
              {profile.profilePicture && (
                <div className="bg-cream p-5 rounded-lg border border-golden">
                  <h3 className="font-bold text-maroon text-xl mb-3 font-tamil flex items-center">
                    <FileText className="h-5 w-5 mr-2" />
                    📜 ஜாதகம் இணைப்பு
                  </h3>
                  <div className="flex items-center justify-center h-32 bg-gradient-to-br from-golden/20 to-maroon/10 rounded-lg">
                    <p className="font-tamil text-maroon-dark text-center">ஜாதகம் பதிவேற்றப்பட்டது</p>
                  </div>
                </div>
              )}
            </div>

            {/* Horoscope Grids Display */}
            {profile.jathagamKattam && (
              <div className="mb-6">
                <h3 className="text-2xl font-tamil font-semibold text-maroon border-b-2 border-golden pb-2 mb-6">
                  ஜாதகம் கட்டம்
                </h3>
                <div className="grid lg:grid-cols-2 gap-8">
                  {renderHoroscopeGrid(profile.jathagamKattam.rasiKattam.cells, 'ராசி கட்டம்', 'ராசி')}
                  {renderHoroscopeGrid(profile.jathagamKattam.navamsamKattam.cells, 'நவாம்சம் கட்டம்', 'நவாம்சம்')}
                </div>
              </div>
            )}

            {identity && isOwnProfile && (
              <div className="flex justify-center mt-8">
                <Button 
                  onClick={() => navigate({ to: '/profile/edit' })}
                  className="bg-golden hover:bg-golden-dark text-maroon-dark font-tamil text-lg px-8 py-6"
                >
                  <Edit className="h-5 w-5 mr-2" />
                  திருத்து சுயவிவரம்
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
