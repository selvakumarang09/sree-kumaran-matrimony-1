import { useState } from 'react';
import { useNavigate } from '@tanstack/react-router';
import { Card, CardContent } from '../components/ui/card';
import { Shield, Users, Search } from 'lucide-react';
import { SiFacebook, SiX, SiInstagram, SiYoutube } from 'react-icons/si';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { useSearchProfileByMatrimonyId } from '../hooks/useQueries';
import type { Profile } from '../backend';

export default function HomePage() {
  const navigate = useNavigate();
  const [matrimonyId, setMatrimonyId] = useState('');
  const [searchResult, setSearchResult] = useState<Profile | null | undefined>(undefined);

  const searchMutation = useSearchProfileByMatrimonyId();

  const handleSearch = async () => {
    if (matrimonyId.trim()) {
      try {
        const result = await searchMutation.mutateAsync(matrimonyId.trim());
        setSearchResult(result);
      } catch (error) {
        console.error('Search error:', error);
        setSearchResult(null);
      }
    }
  };

  const handleViewProfile = () => {
    if (searchResult) {
      navigate({ to: '/profile/$profileId', params: { profileId: searchResult.id } });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-cream via-white to-cream">
      {/* Hero Section */}
      <section className="py-16 md:py-24 px-4">
        <div className="container mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-maroon mb-4 font-tamil">
            உங்கள் வாழ்க்கை துணையை கண்டுபிடிக்கவும்
          </h1>
          <p className="text-lg md:text-xl text-maroon-dark mb-8 font-tamil max-w-3xl mx-auto">
            நம்பகமான மற்றும் பாரம்பரிய திருமண சேவை. ஆயிரக்கணக்கான வெற்றிகரமான திருமணங்கள்.
          </p>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mt-8">
            <Button
              onClick={() => navigate({ to: '/register' })}
              className="bg-maroon hover:bg-maroon-dark text-golden font-tamil text-lg px-8 py-6 rounded-full shadow-lg hover:shadow-xl transition-all"
            >
              பதிவு செய்க
            </Button>
            <Button
              onClick={() => {
                const searchSection = document.getElementById('advanced-search');
                searchSection?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="bg-golden hover:bg-golden/90 text-maroon font-tamil text-lg px-8 py-6 rounded-full shadow-lg hover:shadow-xl transition-all"
            >
              மேம்பட்ட தேடல்
            </Button>
          </div>
        </div>
      </section>

      {/* Advanced Search by Matrimony ID Section */}
      <section id="advanced-search" className="py-16 px-4 bg-white">
        <div className="container mx-auto max-w-2xl">
          <Card className="border-2 border-golden shadow-xl">
            <CardContent className="p-8">
              <h2 className="text-3xl md:text-4xl font-bold text-maroon text-center mb-3 font-tamil">
                மேம்பட்ட தேடல்
              </h2>
              <p className="text-center text-maroon-dark font-tamil mb-6">
                Matrimony ID மூலம் சுயவிவரம் தேடுங்கள்
              </p>

              <div className="flex flex-col sm:flex-row gap-4">
                <Input
                  type="text"
                  placeholder="உதாரணம்: SKM00001"
                  value={matrimonyId}
                  onChange={(e) => {
                    setMatrimonyId(e.target.value);
                    setSearchResult(undefined);
                  }}
                  className="flex-1 border-2 border-maroon focus:border-golden font-tamil text-lg"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      handleSearch();
                    }
                  }}
                />
                <Button
                  onClick={handleSearch}
                  disabled={searchMutation.isPending || !matrimonyId.trim()}
                  className="bg-maroon hover:bg-maroon-dark text-golden font-tamil text-lg px-8 py-2 rounded-lg shadow-md hover:shadow-lg transition-all"
                >
                  {searchMutation.isPending ? 'தேடுகிறது...' : 'தேடு'}
                </Button>
              </div>

              {/* Search Results */}
              {searchResult !== undefined && !searchMutation.isPending && (
                <div className="mt-6">
                  {searchResult ? (
                    <Card className="border-2 border-golden bg-cream">
                      <CardContent className="p-6">
                        <div className="flex flex-col md:flex-row gap-4 items-start">
                          <div className="flex-1">
                            <h3 className="text-2xl font-bold text-maroon mb-2 font-tamil">
                              {searchResult.name}
                            </h3>
                            <div className="space-y-1 text-maroon-dark font-tamil">
                              <p>
                                <span className="font-semibold">Matrimony ID:</span> {searchResult.id}
                              </p>
                              <p>
                                <span className="font-semibold">வயது:</span> {searchResult.age.toString()}
                              </p>
                              <p>
                                <span className="font-semibold">உயரம்:</span> {searchResult.heightCm.toString()} cm
                              </p>
                              <p>
                                <span className="font-semibold">கல்வி:</span> {searchResult.education}
                              </p>
                              <p>
                                <span className="font-semibold">தொழில்:</span> {searchResult.occupation}
                              </p>
                            </div>
                            <Button
                              onClick={handleViewProfile}
                              className="mt-4 bg-golden hover:bg-golden/90 text-maroon font-tamil"
                            >
                              முழு சுயவிவரத்தை பார்க்கவும்
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ) : (
                    <div className="text-center py-6">
                      <p className="text-maroon font-tamil text-lg">
                        சுயவிவரம் கிடைக்கவில்லை
                      </p>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-16 px-4 bg-gradient-to-r from-cream via-white to-cream">
        <div className="container mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-maroon text-center mb-12 font-tamil">
            ஏன் எங்களை தேர்வு செய்ய வேண்டும்?
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="border-2 border-golden shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="p-8 text-center">
                <div className="flex justify-center mb-4">
                  <div className="bg-maroon p-4 rounded-full">
                    <Shield className="h-10 w-10 text-golden" />
                  </div>
                </div>
                <h3 className="text-2xl font-bold text-maroon mb-3 font-tamil">
                  நம்பகமான சேவை
                </h3>
                <p className="text-maroon-dark font-tamil">
                  அனைத்து சுயவிவரங்களும் சரிபார்க்கப்பட்டவை மற்றும் பாதுகாப்பானவை
                </p>
              </CardContent>
            </Card>

            <Card className="border-2 border-golden shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="p-8 text-center">
                <div className="flex justify-center mb-4">
                  <div className="bg-maroon p-4 rounded-full">
                    <Users className="h-10 w-10 text-golden" />
                  </div>
                </div>
                <h3 className="text-2xl font-bold text-maroon mb-3 font-tamil">
                  பெரிய சமூகம்
                </h3>
                <p className="text-maroon-dark font-tamil">
                  ஆயிரக்கணக்கான சுயவிவரங்கள் உங்கள் தேர்வுக்காக காத்திருக்கின்றன
                </p>
              </CardContent>
            </Card>

            <Card className="border-2 border-golden shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="p-8 text-center">
                <div className="flex justify-center mb-4">
                  <div className="bg-maroon p-4 rounded-full">
                    <Search className="h-10 w-10 text-golden" />
                  </div>
                </div>
                <h3 className="text-2xl font-bold text-maroon mb-3 font-tamil">
                  மேம்பட்ட தேடல்
                </h3>
                <p className="text-maroon-dark font-tamil">
                  உங்கள் விருப்பங்களுக்கு ஏற்ற சுயவிவரங்களை எளிதாக கண்டுபிடிக்கவும்
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Call to Action Section */}
      <section className="py-16 px-4 bg-gradient-to-r from-maroon via-maroon-dark to-maroon">
        <div className="container mx-auto text-center">
          <h2 className="text-3xl md:text-5xl font-bold text-golden mb-4 font-tamil">
            உங்கள் பயணத்தை இன்றே தொடங்குங்கள்
          </h2>
          <p className="text-lg md:text-xl text-cream mb-8 font-tamil max-w-2xl mx-auto">
            உங்கள் சரியான வாழ்க்கை துணையை கண்டுபிடிக்க இப்போதே இணையுங்கள்
          </p>
        </div>
      </section>

      {/* Footer Section */}
      <footer className="py-12 px-4 bg-gradient-to-b from-cream to-white border-t-2 border-golden">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-3 gap-8">
            {/* About Section */}
            <div>
              <h3 className="text-2xl font-bold text-maroon mb-4 font-tamil">
                ஸ்ரீ குமரன் மேட்ரிமோனி
              </h3>
              <p className="text-maroon-dark font-tamil">
                நம்பகமான மற்றும் பாரம்பரிய திருமண சேவை. உங்கள் வாழ்க்கை துணையை கண்டுபிடிக்க நாங்கள் உதவுகிறோம்.
              </p>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="text-xl font-bold text-maroon mb-4 font-tamil">
                விரைவு இணைப்புகள்
              </h4>
              <ul className="space-y-2">
                <li>
                  <button
                    onClick={() => navigate({ to: '/about' })}
                    className="text-maroon-dark hover:text-maroon font-tamil transition-colors"
                  >
                    எங்களை பற்றி
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => navigate({ to: '/pricing' })}
                    className="text-maroon-dark hover:text-maroon font-tamil transition-colors"
                  >
                    விலை நிர்ணயம்
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => navigate({ to: '/contact' })}
                    className="text-maroon-dark hover:text-maroon font-tamil transition-colors"
                  >
                    தொடர்பு
                  </button>
                </li>
              </ul>
            </div>

            {/* Social Links */}
            <div>
              <h4 className="text-xl font-bold text-maroon mb-4 font-tamil">
                எங்களை பின்தொடரவும்
              </h4>
              <div className="flex gap-4">
                <a
                  href="#"
                  className="bg-maroon p-3 rounded-full hover:bg-maroon-dark transition-colors"
                  aria-label="Facebook"
                >
                  <SiFacebook className="h-5 w-5 text-golden" />
                </a>
                <a
                  href="#"
                  className="bg-maroon p-3 rounded-full hover:bg-maroon-dark transition-colors"
                  aria-label="X (Twitter)"
                >
                  <SiX className="h-5 w-5 text-golden" />
                </a>
                <a
                  href="#"
                  className="bg-maroon p-3 rounded-full hover:bg-maroon-dark transition-colors"
                  aria-label="Instagram"
                >
                  <SiInstagram className="h-5 w-5 text-golden" />
                </a>
                <a
                  href="#"
                  className="bg-maroon p-3 rounded-full hover:bg-maroon-dark transition-colors"
                  aria-label="YouTube"
                >
                  <SiYoutube className="h-5 w-5 text-golden" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
