import { useState, useEffect } from 'react';
import { useIsCallerAdmin, useGetAllProfiles, useGetAllContactForms, useDeleteProfile, useTogglePremiumStatus, useGetAdminAnalytics } from '../hooks/useQueries';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../components/ui/table';
import { Crown, Trash2, Users, Mail, BarChart3, TrendingUp, Activity } from 'lucide-react';
import { toast } from 'sonner';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export default function AdminPage() {
  const { data: isAdmin, isLoading: adminLoading } = useIsCallerAdmin();
  const { data: profiles = [], refetch: refetchProfiles } = useGetAllProfiles();
  const { data: contacts = [] } = useGetAllContactForms();
  const { data: analytics, refetch: refetchAnalytics } = useGetAdminAnalytics();
  const deleteProfile = useDeleteProfile();
  const togglePremium = useTogglePremiumStatus();
  const [animateCards, setAnimateCards] = useState(false);

  // Auto-refresh every 30 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      refetchAnalytics();
      refetchProfiles();
    }, 30000);
    return () => clearInterval(interval);
  }, [refetchAnalytics, refetchProfiles]);

  // Trigger card animations on mount
  useEffect(() => {
    setTimeout(() => setAnimateCards(true), 100);
  }, []);

  const handleDelete = async (profileId: string) => {
    if (!confirm('இந்த சுயவிவரத்தை நீக்க விரும்புகிறீர்களா?')) return;
    try {
      await deleteProfile.mutateAsync(profileId);
      toast.success('சுயவிவரம் நீக்கப்பட்டது');
      refetchProfiles();
      refetchAnalytics();
    } catch (error) {
      toast.error('நீக்குதல் தோல்வியடைந்தது');
    }
  };

  const handleTogglePremium = async (profileId: string) => {
    try {
      await togglePremium.mutateAsync(profileId);
      toast.success('Premium நிலை மாற்றப்பட்டது');
      refetchProfiles();
      refetchAnalytics();
    } catch (error) {
      toast.error('மாற்றம் தோல்வியடைந்தது');
    }
  };

  if (adminLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-cream via-white to-cream flex items-center justify-center">
        <p className="text-xl text-maroon font-tamil">ஏற்றுகிறது...</p>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-cream via-white to-cream flex items-center justify-center">
        <Card className="border-2 border-maroon shadow-xl max-w-md">
          <CardContent className="p-8 text-center">
            <p className="text-xl text-maroon font-tamil">அணுகல் மறுக்கப்பட்டது</p>
            <p className="text-maroon-dark font-tamil mt-2">நீங்கள் நிர்வாகி அல்ல</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Prepare chart data
  const genderData = analytics ? [
    { name: 'ஆண்', value: Number(analytics.maleCount), fill: 'oklch(var(--maroon))' },
    { name: 'பெண்', value: Number(analytics.femaleCount), fill: 'oklch(var(--golden))' }
  ] : [];

  const maritalStatusData = analytics ? [
    { name: 'திருமணம் ஆகாதவர்', count: Number(analytics.singleCount) },
    { name: 'விவாகரத்து', count: Number(analytics.divorcedCount) },
    { name: 'விவாகரத்திற்காக காத்திருப்பவர்', count: Number(analytics.widowedCount) }
  ] : [];

  const districtData = analytics ? analytics.districtDistribution
    .map(([district, count]) => ({ district, count: Number(count) }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 10) : [];

  // Get current month profiles
  const currentMonth = new Date().getMonth() + 1;
  const currentMonthProfiles = analytics?.monthlyProfiles.find(m => Number(m.month) === currentMonth);
  const thisMonthCount = currentMonthProfiles ? Number(currentMonthProfiles.count) : 0;

  const totalProfiles = profiles.length;
  const premiumProfiles = profiles.filter(p => p.premiumMember).length;

  // Custom tooltip for charts
  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white border-2 border-golden p-3 rounded-lg shadow-lg">
          <p className="font-tamil text-maroon font-semibold">{payload[0].name}</p>
          <p className="font-tamil text-maroon-dark">எண்ணிக்கை: {payload[0].value}</p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-cream via-white to-cream py-12 px-4">
      <div className="container mx-auto max-w-7xl">
        <h1 className="text-4xl font-bold text-maroon mb-8 text-center font-tamil">நிர்வாக பலகம்</h1>

        {/* Animated Summary Cards */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card 
            className={`border-2 border-golden shadow-lg transition-all duration-700 ${
              animateCards ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
            style={{ transitionDelay: '0ms' }}
          >
            <CardContent className="p-6 text-center">
              <Users className="h-12 w-12 text-maroon mx-auto mb-2" />
              <p className="text-4xl font-bold text-maroon">{analytics ? Number(analytics.totalProfiles) : 0}</p>
              <p className="text-maroon-dark font-tamil mt-1">மொத்த பதிவு செய்யப்பட்ட பயனர்கள்</p>
            </CardContent>
          </Card>
          
          <Card 
            className={`border-2 border-golden shadow-lg transition-all duration-700 ${
              animateCards ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
            style={{ transitionDelay: '150ms' }}
          >
            <CardContent className="p-6 text-center">
              <Activity className="h-12 w-12 text-golden mx-auto mb-2" />
              <p className="text-4xl font-bold text-maroon">{analytics ? Number(analytics.totalUsers) : 0}</p>
              <p className="text-maroon-dark font-tamil mt-1">செயலில் உள்ள பயனர்கள்</p>
            </CardContent>
          </Card>
          
          <Card 
            className={`border-2 border-golden shadow-lg transition-all duration-700 ${
              animateCards ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
            style={{ transitionDelay: '300ms' }}
          >
            <CardContent className="p-6 text-center">
              <TrendingUp className="h-12 w-12 text-maroon mx-auto mb-2" />
              <p className="text-4xl font-bold text-maroon">{thisMonthCount}</p>
              <p className="text-maroon-dark font-tamil mt-1">இந்த மாதம் உருவாக்கப்பட்ட சுயவிவரங்கள்</p>
            </CardContent>
          </Card>
        </div>

        {/* Charts Section */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          {/* Gender Distribution Pie Chart */}
          <Card className="border-2 border-golden shadow-lg">
            <CardHeader className="bg-gradient-to-r from-maroon to-maroon-dark text-white">
              <CardTitle className="font-tamil">பாலின விநியோகம்</CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={genderData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                    animationBegin={0}
                    animationDuration={800}
                  >
                    {genderData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Pie>
                  <Tooltip content={<CustomTooltip />} />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Marital Status Bar Chart */}
          <Card className="border-2 border-golden shadow-lg">
            <CardHeader className="bg-gradient-to-r from-maroon to-maroon-dark text-white">
              <CardTitle className="font-tamil">திருமண நிலை பிரிவு</CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={maritalStatusData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(var(--border))" />
                  <XAxis 
                    dataKey="name" 
                    tick={{ fill: 'oklch(var(--maroon))', fontSize: 12 }}
                    angle={-15}
                    textAnchor="end"
                    height={80}
                  />
                  <YAxis tick={{ fill: 'oklch(var(--maroon))' }} />
                  <Tooltip content={<CustomTooltip />} />
                  <Bar 
                    dataKey="count" 
                    fill="oklch(var(--golden))" 
                    animationBegin={0}
                    animationDuration={800}
                  />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Top Districts Bar Chart */}
        <Card className="border-2 border-golden shadow-lg mb-8">
          <CardHeader className="bg-gradient-to-r from-maroon to-maroon-dark text-white">
            <CardTitle className="font-tamil">உறுப்பினர் எண்ணிக்கையின் அடிப்படையில் முதன்மை மாவட்டங்கள்</CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <ResponsiveContainer width="100%" height={400}>
              <BarChart data={districtData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(var(--border))" />
                <XAxis type="number" tick={{ fill: 'oklch(var(--maroon))' }} />
                <YAxis 
                  dataKey="district" 
                  type="category" 
                  tick={{ fill: 'oklch(var(--maroon))', fontSize: 12 }}
                  width={120}
                />
                <Tooltip content={<CustomTooltip />} />
                <Bar 
                  dataKey="count" 
                  fill="oklch(var(--maroon))" 
                  animationBegin={0}
                  animationDuration={800}
                />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Tabs defaultValue="profiles" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 max-w-md mx-auto">
            <TabsTrigger value="profiles" className="font-tamil">சுயவிவரங்கள்</TabsTrigger>
            <TabsTrigger value="contacts" className="font-tamil">தொடர்புகள்</TabsTrigger>
          </TabsList>

          <TabsContent value="profiles">
            <Card className="border-2 border-golden">
              <CardHeader className="bg-gradient-to-r from-maroon to-maroon-dark text-white">
                <CardTitle className="font-tamil">அனைத்து சுயவிவரங்கள்</CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="font-tamil">அடையாள எண்</TableHead>
                        <TableHead className="font-tamil">பெயர்</TableHead>
                        <TableHead className="font-tamil">வயது</TableHead>
                        <TableHead className="font-tamil">பாலினம்</TableHead>
                        <TableHead className="font-tamil">நிலை</TableHead>
                        <TableHead className="font-tamil">செயல்கள்</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {profiles.map((profile) => (
                        <TableRow key={profile.id}>
                          <TableCell className="font-tamil">{profile.id}</TableCell>
                          <TableCell className="font-tamil">{profile.name}</TableCell>
                          <TableCell>{Number(profile.age)}</TableCell>
                          <TableCell className="font-tamil">{profile.gender === 'male' ? 'ஆண்' : 'பெண்'}</TableCell>
                          <TableCell>
                            {profile.premiumMember && (
                              <Badge className="bg-golden text-maroon-dark">
                                <Crown className="h-3 w-3 mr-1" />
                                Premium
                              </Badge>
                            )}
                          </TableCell>
                          <TableCell>
                            <div className="flex gap-2">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleTogglePremium(profile.id)}
                                className="font-tamil"
                              >
                                <Crown className="h-4 w-4 mr-1" />
                                மாற்று
                              </Button>
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={() => handleDelete(profile.id)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="contacts">
            <Card className="border-2 border-golden">
              <CardHeader className="bg-gradient-to-r from-maroon to-maroon-dark text-white">
                <CardTitle className="font-tamil flex items-center gap-2">
                  <Mail className="h-6 w-6" />
                  தொடர்பு செய்திகள்
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-4">
                  {contacts.map((contact, index) => (
                    <Card key={index} className="border border-maroon-light">
                      <CardContent className="p-4">
                        <div className="space-y-2 font-tamil">
                          <p><strong>பெயர்:</strong> {contact.name}</p>
                          <p><strong>மின்னஞ்சல்:</strong> {contact.email}</p>
                          <p><strong>செய்தி:</strong> {contact.message}</p>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                  {contacts.length === 0 && (
                    <p className="text-center text-maroon-dark font-tamil py-8">செய்திகள் இல்லை</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
