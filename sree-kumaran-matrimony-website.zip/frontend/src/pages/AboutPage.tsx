import { useNavigate } from '@tanstack/react-router';
import { Card, CardContent } from '../components/ui/card';
import { Heart, Shield, Users, Home, Sparkles, Star } from 'lucide-react';
import { SiFacebook, SiX, SiInstagram, SiYoutube } from 'react-icons/si';

export default function AboutPage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-b from-cream via-white to-cream">
      {/* Header Section */}
      <section className="py-12 md:py-16 px-4 bg-gradient-to-r from-maroon via-maroon-dark to-maroon">
        <div className="container mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-golden mb-3 font-tamil">
            எங்களை பற்றி
          </h1>
          <p className="text-xl md:text-2xl text-cream font-tamil">
            உறவுகளின் தொடக்கம்
          </p>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-12 px-4">
        <div className="container mx-auto max-w-5xl space-y-8">
          {/* எங்கள் நோக்கம் Section */}
          <Card className="border-2 border-golden shadow-lg">
            <CardContent className="p-8">
              <div className="flex items-center gap-3 mb-6">
                <div className="bg-maroon p-3 rounded-full">
                  <Heart className="h-6 w-6 text-golden" />
                </div>
                <h2 className="text-3xl font-bold text-maroon font-tamil">
                  எங்கள் நோக்கம்
                </h2>
              </div>
              <div className="space-y-4 text-maroon-dark font-tamil text-lg leading-relaxed">
                <p>
                  ஸ்ரீ குமரன் மேட்ரிமோனி என்பது பாரம்பரிய தமிழ் மதிப்புகளை மதிக்கும் ஒரு திருமண சேவையாகும். 
                  நாங்கள் குடும்பங்களை இணைக்கவும், வாழ்நாள் முழுவதும் நீடிக்கும் உறவுகளை உருவாக்கவும் உதவுகிறோம்.
                </p>
                <p>
                  திருமணம் என்பது இரண்டு உயிர்களின் இணைப்பு மட்டுமல்ல, இரண்டு குடும்பங்களின் புனிதமான பந்தமாகும். 
                  இந்த புனிதமான பயணத்தில் உங்களுக்கு வழிகாட்டியாக இருப்பதில் நாங்கள் பெருமிதம் கொள்கிறோம்.
                </p>
                <p>
                  எங்கள் சேவை நம்பிக்கை, மரியாதை மற்றும் பாரம்பரிய மதிப்புகளின் அடித்தளத்தில் கட்டமைக்கப்பட்டுள்ளது. 
                  ஒவ்வொரு குடும்பமும் தனித்துவமானது என்பதை நாங்கள் புரிந்துகொள்கிறோம், அதனால் ஒவ்வொரு தேடலும் தனிப்பட்ட கவனத்துடன் கையாளப்படுகிறது.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* நம்பிக்கை Section */}
          <Card className="border-2 border-golden shadow-lg">
            <CardContent className="p-8">
              <div className="flex items-center gap-3 mb-6">
                <div className="bg-maroon p-3 rounded-full">
                  <Shield className="h-6 w-6 text-golden" />
                </div>
                <h2 className="text-3xl font-bold text-maroon font-tamil">
                  நம்பிக்கை
                </h2>
              </div>
              <div className="space-y-4 text-maroon-dark font-tamil text-lg leading-relaxed">
                <p>
                  உங்கள் தனிப்பட்ட தகவல்களின் பாதுகாப்பு எங்களுக்கு மிக முக்கியம். 
                  நாங்கள் அனைத்து தகவல்களையும் பாதுகாப்பாக வைத்திருக்கிறோம் மற்றும் 
                  உங்கள் அனுமதியின்றி யாருடனும் பகிர்வதில்லை.
                </p>
                <p>
                  ஒவ்வொரு சுயவிவரமும் கவனமாக சரிபார்க்கப்படுகிறது. நம்பகத்தன்மை மற்றும் 
                  வெளிப்படைத்தன்மை எங்கள் சேவையின் முக்கிய அம்சங்களாகும்.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* குடும்ப மதிப்புகள் Section */}
          <Card className="border-2 border-golden shadow-lg">
            <CardContent className="p-8">
              <div className="flex items-center gap-3 mb-6">
                <div className="bg-maroon p-3 rounded-full">
                  <Users className="h-6 w-6 text-golden" />
                </div>
                <h2 className="text-3xl font-bold text-maroon font-tamil">
                  குடும்ப மதிப்புகள்
                </h2>
              </div>
              <div className="space-y-4 text-maroon-dark font-tamil text-lg leading-relaxed">
                <p>
                  குடும்பம் என்பது நமது சமூகத்தின் அடித்தளம். பாரம்பரிய குடும்ப மதிப்புகளை 
                  போற்றுவதும், அடுத்த தலைமுறைக்கு அவற்றை கடத்துவதும் எங்கள் நோக்கமாகும்.
                </p>
                <p>
                  பெற்றோர்களின் ஆசீர்வாதம், குடும்பத்தினரின் ஒப்புதல் மற்றும் பரஸ்பர மரியாதை 
                  ஆகியவை வெற்றிகரமான திருமண வாழ்க்கைக்கு அவசியம் என்று நாங்கள் நம்புகிறோம்.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* எளிமை Section */}
          <Card className="border-2 border-golden shadow-lg">
            <CardContent className="p-8">
              <div className="flex items-center gap-3 mb-6">
                <div className="bg-maroon p-3 rounded-full">
                  <Sparkles className="h-6 w-6 text-golden" />
                </div>
                <h2 className="text-3xl font-bold text-maroon font-tamil">
                  எளிமை
                </h2>
              </div>
              <div className="space-y-4 text-maroon-dark font-tamil text-lg leading-relaxed">
                <p>
                  எங்கள் சேவை எளிமையானது மற்றும் பயன்படுத்த எளிதானது. சிக்கலான செயல்முறைகள் 
                  இல்லாமல், உங்கள் வாழ்க்கை துணையை கண்டுபிடிப்பதில் கவனம் செலுத்துங்கள்.
                </p>
                <p>
                  தெளிவான தேடல் வசதிகள், எளிய பதிவு செயல்முறை மற்றும் உதவிகரமான ஆதரவு 
                  ஆகியவை உங்கள் அனுபவத்தை மகிழ்ச்சிகரமானதாக ஆக்குகின்றன.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* பாரம்பரியம் Section */}
          <Card className="border-2 border-golden shadow-lg">
            <CardContent className="p-8">
              <div className="flex items-center gap-3 mb-6">
                <div className="bg-maroon p-3 rounded-full">
                  <Home className="h-6 w-6 text-golden" />
                </div>
                <h2 className="text-3xl font-bold text-maroon font-tamil">
                  பாரம்பரியம்
                </h2>
              </div>
              <div className="space-y-4 text-maroon-dark font-tamil text-lg leading-relaxed">
                <p>
                  தமிழ் கலாச்சாரம் மற்றும் பாரம்பரியம் எங்கள் சேவையின் இதயமாகும். 
                  ஜாதகப் பொருத்தம், குலம், கோத்திரம் போன்ற பாரம்பரிய அம்சங்களுக்கு 
                  நாங்கள் முக்கியத்துவம் அளிக்கிறோம்.
                </p>
                <p>
                  நவீன தொழில்நுட்பத்துடன் பாரம்பரிய மதிப்புகளை இணைத்து, சிறந்த 
                  திருமண சேவையை வழங்குகிறோம்.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* ஏன் எங்களை தேர்வு செய்ய வேண்டும்? Section */}
          <Card className="border-2 border-golden shadow-lg bg-gradient-to-br from-cream to-white">
            <CardContent className="p-8">
              <div className="flex items-center gap-3 mb-6">
                <div className="bg-maroon p-3 rounded-full">
                  <Star className="h-6 w-6 text-golden" />
                </div>
                <h2 className="text-3xl font-bold text-maroon font-tamil">
                  ஏன் எங்களை தேர்வு செய்ய வேண்டும்?
                </h2>
              </div>
              <div className="space-y-4 text-maroon-dark font-tamil text-lg leading-relaxed">
                <p>
                  ஸ்ரீ குமரன் மேட்ரிமோனி - பாரம்பரிய தமிழ் திருமண சேவை. நம்பகமான, 
                  பாதுகாப்பான மற்றும் குடும்ப மதிப்புகளை மதிக்கும் சேவை.
                </p>
                <ul className="space-y-3 ml-6">
                  <li className="flex items-start gap-2">
                    <span className="text-golden mt-1">✓</span>
                    <span>சரிபார்க்கப்பட்ட சுயவிவரங்கள்</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-golden mt-1">✓</span>
                    <span>தனியுரிமை பாதுகாப்பு</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-golden mt-1">✓</span>
                    <span>மேம்பட்ட தேடல் வசதிகள்</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-golden mt-1">✓</span>
                    <span>பாரம்பரிய மதிப்புகளை மதித்தல்</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-golden mt-1">✓</span>
                    <span>24/7 ஆதரவு சேவை</span>
                  </li>
                </ul>
                <p className="pt-4 font-semibold">
                  உங்கள் வாழ்க்கைத் துணையை கண்டறிய எங்களுடன் இணையுங்கள்.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer Section */}
      <footer className="py-12 px-4 bg-gradient-to-b from-cream to-white border-t-2 border-golden mt-12">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-3 gap-8">
            {/* About Section */}
            <div>
              <h3 className="text-2xl font-bold text-maroon mb-4 font-tamil">
                ஸ்ரீ குமரன் மேட்ரிமோனி
              </h3>
              <p className="text-maroon-dark font-tamil">
                நம்பகமான மற்றும் பாரம்பரிய திருமண சேவை. உங்கள் வாழ்க்கை துணையை கண்டுபிடிக்க நாங்கள் உதவுகிறோம்.
              </p>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="text-xl font-bold text-maroon mb-4 font-tamil">
                விரைவு இணைப்புகள்
              </h4>
              <ul className="space-y-2">
                <li>
                  <button
                    onClick={() => navigate({ to: '/about' })}
                    className="text-maroon-dark hover:text-maroon font-tamil transition-colors"
                  >
                    எங்களை பற்றி
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => navigate({ to: '/pricing' })}
                    className="text-maroon-dark hover:text-maroon font-tamil transition-colors"
                  >
                    விலை நிர்ணயம்
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => navigate({ to: '/contact' })}
                    className="text-maroon-dark hover:text-maroon font-tamil transition-colors"
                  >
                    தொடர்பு
                  </button>
                </li>
              </ul>
            </div>

            {/* Social Links */}
            <div>
              <h4 className="text-xl font-bold text-maroon mb-4 font-tamil">
                எங்களை பின்தொடரவும்
              </h4>
              <div className="flex gap-4">
                <a
                  href="#"
                  className="bg-maroon p-3 rounded-full hover:bg-maroon-dark transition-colors"
                  aria-label="Facebook"
                >
                  <SiFacebook className="h-5 w-5 text-golden" />
                </a>
                <a
                  href="#"
                  className="bg-maroon p-3 rounded-full hover:bg-maroon-dark transition-colors"
                  aria-label="X (Twitter)"
                >
                  <SiX className="h-5 w-5 text-golden" />
                </a>
                <a
                  href="#"
                  className="bg-maroon p-3 rounded-full hover:bg-maroon-dark transition-colors"
                  aria-label="Instagram"
                >
                  <SiInstagram className="h-5 w-5 text-golden" />
                </a>
                <a
                  href="#"
                  className="bg-maroon p-3 rounded-full hover:bg-maroon-dark transition-colors"
                  aria-label="YouTube"
                >
                  <SiYoutube className="h-5 w-5 text-golden" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
