import { Mail } from 'lucide-react';
import { SiFacebook, SiX, SiInstagram } from 'react-icons/si';
import { Link } from '@tanstack/react-router';

export default function ContactPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-cream via-white to-cream">
      {/* Hero Section */}
      <section className="py-16 px-4">
        <div className="container mx-auto max-w-4xl">
          <h1 className="text-4xl md:text-5xl font-bold text-maroon-dark text-center mb-6 font-tamil">
            எங்களை தொடர்பு கொள்ளுங்கள்
          </h1>
          
          <div className="bg-white rounded-lg shadow-lg border-2 border-golden p-8 md:p-12 space-y-6">
            {/* Introduction */}
            <div className="text-center mb-8">
              <p className="text-xl text-maroon font-tamil font-semibold mb-4">
                உங்கள் கேள்விகளுக்கு நாங்கள் உதவ தயாராக உள்ளோம்
              </p>
            </div>

            {/* Description Paragraphs */}
            <div className="space-y-4 text-gray-700 font-tamil text-lg leading-relaxed">
              <p>
                ஸ்ரீ குமரன் மேட்ரிமோனி - பாரம்பரிய தமிழ் திருமண சேவை. நம்பகமான, பாதுகாப்பான மற்றும் குடும்ப மதிப்புகளை மதிக்கும் சேவை.
              </p>
              
              <p>
                உங்கள் வாழ்க்கைத் துணையை கண்டறிய, எங்கள் சேவைகள் பற்றி மேலும் அறிய, அல்லது ஏதேனும் உதவி தேவைப்பட்டால், தயவுசெய்து எங்களை தொடர்பு கொள்ளுங்கள். உங்கள் கேள்விகளுக்கு விரைவில் பதிலளிக்க நாங்கள் கடமைப்பட்டுள்ளோம்.
              </p>

              <p className="text-center text-maroon font-semibold text-xl pt-4">
                உறவுகளின் தொடக்கம் - நம்பிக்கையுடன், பாரம்பரியத்துடன்
              </p>
            </div>

            {/* Contact Information */}
            <div className="mt-12 pt-8 border-t-2 border-golden">
              <h2 className="text-2xl font-bold text-maroon-dark text-center mb-6 font-tamil">
                தொடர்பு தகவல்
              </h2>
              
              <div className="flex items-center justify-center gap-3 text-lg font-tamil bg-cream p-6 rounded-lg border border-golden">
                <Mail className="h-6 w-6 text-maroon" />
                <span className="text-maroon-dark font-semibold">மின்னஞ்சல்:</span>
                <a 
                  href="mailto:sreekumaranmatrimony@gmail.com" 
                  className="text-maroon hover:text-maroon-dark underline"
                >
                  sreekumaranmatrimony@gmail.com
                </a>
              </div>
            </div>

            {/* Promise Section */}
            <div className="mt-12 pt-8 border-t-2 border-golden">
              <h2 className="text-2xl font-bold text-maroon-dark text-center mb-6 font-tamil">
                எங்கள் வாக்குறுதி
              </h2>
              
              <p className="text-gray-700 font-tamil text-lg leading-relaxed text-center">
                உங்கள் தனிப்பட்ட தகவல்கள் முழு பாதுகாப்புடன் கையாளப்படும். நம்பிக்கை, பாரம்பரியம் மற்றும் குடும்ப மதிப்புகளை மதித்து, உங்கள் வாழ்க்கைத் துணையை கண்டறிய நாங்கள் உதவுகிறோம்.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gradient-to-r from-maroon to-maroon-dark text-white py-12 px-4 mt-16">
        <div className="container mx-auto max-w-6xl">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* About Section */}
            <div>
              <h3 className="text-xl font-bold mb-4 font-tamil">ஸ்ரீ குமரன் மேட்ரிமோனி</h3>
              <p className="text-cream font-tamil leading-relaxed">
                நம்பகமான மற்றும் பாரம்பரிய திருமண சேவை. உங்கள் வாழ்க்கை துணையை கண்டுபிடிக்க நாங்கள் உதவுகிறோம்.
              </p>
            </div>

            {/* Quick Links */}
            <div>
              <h3 className="text-xl font-bold mb-4 font-tamil">விரைவு இணைப்புகள்</h3>
              <ul className="space-y-2 font-tamil">
                <li>
                  <Link to="/about" className="text-cream hover:text-golden transition-colors">
                    எங்களை பற்றி
                  </Link>
                </li>
                <li>
                  <Link to="/pricing" className="text-cream hover:text-golden transition-colors">
                    விலை நிர்ணயம்
                  </Link>
                </li>
                <li>
                  <Link to="/contact" className="text-cream hover:text-golden transition-colors">
                    தொடர்பு
                  </Link>
                </li>
              </ul>
            </div>

            {/* Social Links */}
            <div>
              <h3 className="text-xl font-bold mb-4 font-tamil">எங்களை பின்தொடரவும்</h3>
              <div className="flex gap-4">
                <a href="#" className="text-cream hover:text-golden transition-colors">
                  <SiFacebook className="h-6 w-6" />
                </a>
                <a href="#" className="text-cream hover:text-golden transition-colors">
                  <SiX className="h-6 w-6" />
                </a>
                <a href="#" className="text-cream hover:text-golden transition-colors">
                  <SiInstagram className="h-6 w-6" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
