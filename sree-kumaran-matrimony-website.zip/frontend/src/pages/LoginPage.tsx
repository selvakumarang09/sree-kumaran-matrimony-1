import { useState } from 'react';
import { useNavigate } from '@tanstack/react-router';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { LogIn, Shield } from 'lucide-react';
import { useAuthenticateUser } from '../hooks/useQueries';
import { toast } from 'sonner';

export default function LoginPage() {
  const navigate = useNavigate();
  const authenticateUser = useAuthenticateUser();
  const [matrimonyId, setMatrimonyId] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!matrimonyId.trim() || !password.trim()) {
      toast.error('அனைத்து புலங்களையும் நிரப்பவும்');
      return;
    }

    try {
      await authenticateUser.mutateAsync({ matrimonyId: matrimonyId.trim(), password });
      toast.success('உள்நுழைவு வெற்றிகரமாக முடிந்தது!');
      navigate({ to: '/' });
    } catch (error: any) {
      console.error('Login error:', error);
      if (error.message?.includes('தவறான Matrimony ID அல்லது கடவுச்சொல்')) {
        toast.error('தவறான Matrimony ID அல்லது கடவுச்சொல்');
      } else {
        toast.error('உள்நுழைவு தோல்வியடைந்தது');
      }
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-cream via-white to-cream flex items-center justify-center py-12 px-4">
      <div className="w-full max-w-2xl space-y-6">
        <Card className="border-2 border-golden shadow-xl">
          <CardHeader className="bg-gradient-to-r from-maroon to-maroon-dark text-white text-center py-8">
            <CardTitle className="text-4xl font-tamil mb-2">உள்நுழைய</CardTitle>
            <CardDescription className="text-cream text-lg font-tamil">
              பாதுகாப்பான மற்றும் எளிமையான உள்நுழைவு
            </CardDescription>
          </CardHeader>
          <CardContent className="p-8 space-y-6">
            <div className="text-center space-y-4 mb-6">
              <div className="flex justify-center">
                <div className="bg-cream p-4 rounded-full">
                  <Shield className="h-12 w-12 text-maroon" />
                </div>
              </div>
              <p className="text-maroon-dark font-tamil text-lg">
                உங்கள் Matrimony ID மற்றும் கடவுச்சொல்லை பயன்படுத்தி உள்நுழையவும்
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="matrimonyId" className="font-tamil text-maroon-dark font-medium text-lg">
                  Matrimony ID *
                </Label>
                <Input
                  id="matrimonyId"
                  type="text"
                  required
                  value={matrimonyId}
                  onChange={(e) => setMatrimonyId(e.target.value)}
                  className="font-tamil border-maroon-light focus:border-golden text-lg py-6"
                  placeholder="எ.கா: SKM00001"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="font-tamil text-maroon-dark font-medium text-lg">
                  கடவுச்சொல் *
                </Label>
                <Input
                  id="password"
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="font-tamil border-maroon-light focus:border-golden text-lg py-6"
                  placeholder="கடவுச்சொல்"
                />
              </div>

              <Button
                type="submit"
                disabled={authenticateUser.isPending}
                className="w-full bg-maroon hover:bg-maroon-dark text-white font-tamil text-xl py-7 rounded-lg shadow-lg disabled:opacity-50"
              >
                <LogIn className="mr-3 h-6 w-6" />
                {authenticateUser.isPending ? 'உள்நுழைகிறது...' : 'உள்நுழைய'}
              </Button>
            </form>

            <div className="mt-6 text-center">
              <p className="text-maroon-dark font-tamil">
                புதிய பயனரா?{' '}
                <button
                  type="button"
                  onClick={() => navigate({ to: '/register' })}
                  className="text-golden hover:text-golden-dark font-semibold underline"
                >
                  இப்போது பதிவு செய்யுங்கள்
                </button>
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
