import { useState, useEffect } from 'react';
import { useSearchProfiles } from '../hooks/useQueries';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { RadioGroup, RadioGroupItem } from '../components/ui/radio-group';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Search } from 'lucide-react';
import type { SearchFilter, Gender, MaritalStatus } from '../backend';
import { casteCategories, getSubcasteOptions } from '../lib/casteMapping';

const tamilNaduDistricts = [
  'அரியலூர்', 'சென்னை', 'கோயம்புத்தூர்', 'கடலூர்', 'தர்மபுரி', 'திண்டுக்கல்', 
  'ஈரோடு', 'கள்ளக்குறிச்சி', 'காஞ்சிபுரம்', 'கன்னியாகுமரி', 'கரூர்', 'கிருஷ்ணகிரி',
  'மதுரை', 'மயிலாடுதுறை', 'நாகப்பட்டினம்', 'நாமக்கல்', 'நீலகிரி', 'பெரம்பலூர்',
  'புதுக்கோட்டை', 'இராமநாதபுரம்', 'ரானிப்பேட்டை', 'சேலம்', 'சிவகங்கை', 'தஞ்சாவூர்',
  'தேனி', 'தூத்துக்குடி', 'திருச்சிராப்பள்ளி', 'திருநெல்வேலி', 'திருப்பத்தூர்', 'திருப்பூர்',
  'திருவள்ளூர்', 'திருவண்ணாமலை', 'திருவாரூர்', 'வேலூர்', 'விழுப்புரம்', 'விருதுநகர்'
];

const rasiList = [
  'மேஷம்', 'ரிஷபம்', 'மிதுனம்', 'கடகம்', 'சிம்மம்', 'கன்னி',
  'துலாம்', 'விருச்சிகம்', 'தனுசு', 'மகரம்', 'கும்பம்', 'மீனம்'
];

const natchatiramList = [
  'அஸ்வினி', 'பரணி', 'கார்த்திகை', 'ரோகிணி', 'மிருகசீரிடம்', 'திருவாதிரை',
  'புனர்பூசம்', 'பூசம்', 'ஆயில்யம்', 'மகம்', 'பூரம்', 'உத்திரம்',
  'ஹஸ்தம்', 'சித்திரை', 'சுவாதி', 'விசாகம்', 'அனுஷம்', 'கேட்டை',
  'மூலம்', 'பூராடம்', 'உத்திராடம்', 'திருவோணம்', 'அவிட்டம்', 'சதயம்',
  'பூரட்டாதி', 'உத்திரட்டாதி', 'ரேவதி'
];

const maritalStatusOptions = [
  'திருமணம் ஆகாதவர்',
  'விவாகரத்து',
  'விவாகரத்திற்காக காத்திருப்பவர்'
];

export default function SearchPage() {
  const searchProfiles = useSearchProfiles();
  const [gender, setGender] = useState<Gender | ''>('');
  const [minAge, setMinAge] = useState('21');
  const [maxAge, setMaxAge] = useState('35');
  const [district, setDistrict] = useState('');
  const [caste, setCaste] = useState('');
  const [subCaste, setSubCaste] = useState('');
  const [rasi, setRasi] = useState('');
  const [natchatiram, setNatchatiram] = useState('');
  const [maritalStatus, setMaritalStatus] = useState('');

  // Dynamic subcaste options based on selected caste
  const [subCasteOptions, setSubCasteOptions] = useState<string[]>([]);

  // Update subcaste options when caste changes
  useEffect(() => {
    const options = getSubcasteOptions(caste);
    setSubCasteOptions(options);
    
    // Clear subcaste if it's not in the new filtered list
    if (subCaste && subCaste !== 'any' && !options.includes(subCaste)) {
      setSubCaste('');
    }
  }, [caste]);

  const handleSearch = async () => {
    // Map Tamil marital status to backend enum
    let maritalStatusEnum: MaritalStatus | undefined = undefined;
    if (maritalStatus === 'திருமணம் ஆகாதவர்') {
      maritalStatusEnum = 'single' as MaritalStatus;
    } else if (maritalStatus === 'விவாகரத்து') {
      maritalStatusEnum = 'divorced' as MaritalStatus;
    } else if (maritalStatus === 'விவாகரத்திற்காக காத்திருப்பவர்') {
      maritalStatusEnum = 'widowed' as MaritalStatus;
    }

    const filters: SearchFilter = {
      gender: gender || undefined,
      minAge: minAge ? BigInt(minAge) : undefined,
      maxAge: maxAge ? BigInt(maxAge) : undefined,
      maritalStatus: maritalStatusEnum,
      starPosition: natchatiram || rasi || undefined,
    };

    try {
      await searchProfiles.mutateAsync(filters);
    } catch (error) {
      console.error('Search error:', error);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-cream via-white to-cream py-12 px-4">
      <div className="container mx-auto max-w-3xl">
        {/* Page Heading */}
        <div className="text-center mb-8">
          <h1 className="text-4xl md:text-5xl font-tamil font-bold text-maroon-dark mb-3">
            தேடல்
          </h1>
          <p className="text-lg md:text-xl font-tamil text-maroon">
            உங்கள் வாழ்க்கைத் துணையை கண்டறியுங்கள்
          </p>
        </div>

        {/* Quick Search Card */}
        <Card className="border-2 border-golden shadow-2xl">
          <CardHeader className="bg-gradient-to-r from-maroon to-maroon-dark text-white">
            <CardTitle className="text-2xl md:text-3xl font-tamil text-center">விரைவு தேடல்</CardTitle>
          </CardHeader>
          <CardContent className="p-6 md:p-8 space-y-6">
            {/* Age Range */}
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="minAge" className="font-tamil text-maroon-dark text-lg mb-2 block">முதல்</Label>
                <Input
                  id="minAge"
                  type="number"
                  value={minAge}
                  onChange={(e) => setMinAge(e.target.value)}
                  className="font-tamil border-maroon-light focus:border-golden text-lg"
                />
              </div>
              <div>
                <Label htmlFor="maxAge" className="font-tamil text-maroon-dark text-lg mb-2 block">வரை</Label>
                <Input
                  id="maxAge"
                  type="number"
                  value={maxAge}
                  onChange={(e) => setMaxAge(e.target.value)}
                  className="font-tamil border-maroon-light focus:border-golden text-lg"
                />
              </div>
            </div>

            {/* Gender */}
            <div>
              <Label className="font-tamil text-maroon-dark text-lg mb-3 block">பாலினம்</Label>
              <RadioGroup value={gender} onValueChange={(value) => setGender(value as Gender)}>
                <div className="flex gap-6">
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="male" id="male" />
                    <Label htmlFor="male" className="font-tamil text-maroon-dark cursor-pointer text-base">ஆண்</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="female" id="female" />
                    <Label htmlFor="female" className="font-tamil text-maroon-dark cursor-pointer text-base">பெண்</Label>
                  </div>
                </div>
              </RadioGroup>
            </div>

            {/* District */}
            <div>
              <Label htmlFor="district" className="font-tamil text-maroon-dark text-lg mb-2 block">மாவட்டம்</Label>
              <Select value={district} onValueChange={setDistrict}>
                <SelectTrigger id="district" className="font-tamil border-maroon-light focus:border-golden">
                  <SelectValue placeholder="தேர்ந்தெடுக்கவும்" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="any" className="font-tamil">Any</SelectItem>
                  {tamilNaduDistricts.map((dist) => (
                    <SelectItem key={dist} value={dist} className="font-tamil">
                      {dist}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Caste */}
            <div>
              <Label htmlFor="caste" className="font-tamil text-maroon-dark text-lg mb-2 block">ஜாதி</Label>
              <Select value={caste} onValueChange={setCaste}>
                <SelectTrigger id="caste" className="font-tamil border-maroon-light focus:border-golden">
                  <SelectValue placeholder="தேர்ந்தெடுக்கவும்" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="any" className="font-tamil">Any</SelectItem>
                  {casteCategories.map((cat) => (
                    <SelectItem key={cat} value={cat} className="font-tamil">
                      {cat}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Sub Caste - Dynamically filtered */}
            <div>
              <Label htmlFor="subCaste" className="font-tamil text-maroon-dark text-lg mb-2 block">துணை ஜாதி</Label>
              <Select value={subCaste} onValueChange={setSubCaste} disabled={!caste || caste === 'any'}>
                <SelectTrigger id="subCaste" className="font-tamil border-maroon-light focus:border-golden">
                  <SelectValue placeholder={!caste || caste === 'any' ? 'முதலில் ஜாதியை தேர்ந்தெடுக்கவும்' : 'தேர்ந்தெடுக்கவும்'} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="any" className="font-tamil">Any</SelectItem>
                  {subCasteOptions.map((subCat) => (
                    <SelectItem key={subCat} value={subCat} className="font-tamil">
                      {subCat}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Rasi */}
            <div>
              <Label htmlFor="rasi" className="font-tamil text-maroon-dark text-lg mb-2 block">ராசி</Label>
              <Select value={rasi} onValueChange={setRasi}>
                <SelectTrigger id="rasi" className="font-tamil border-maroon-light focus:border-golden">
                  <SelectValue placeholder="தேர்ந்தெடுக்கவும்" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="any" className="font-tamil">Any</SelectItem>
                  {rasiList.map((r) => (
                    <SelectItem key={r} value={r} className="font-tamil">
                      {r}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Natchatiram */}
            <div>
              <Label htmlFor="natchatiram" className="font-tamil text-maroon-dark text-lg mb-2 block">நட்சத்திரம்</Label>
              <Select value={natchatiram} onValueChange={setNatchatiram}>
                <SelectTrigger id="natchatiram" className="font-tamil border-maroon-light focus:border-golden">
                  <SelectValue placeholder="தேர்ந்தெடுக்கவும்" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="any" className="font-tamil">Any</SelectItem>
                  {natchatiramList.map((n) => (
                    <SelectItem key={n} value={n} className="font-tamil">
                      {n}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Marital Status */}
            <div>
              <Label htmlFor="maritalStatus" className="font-tamil text-maroon-dark text-lg mb-2 block">திருமண நிலை</Label>
              <Select value={maritalStatus} onValueChange={setMaritalStatus}>
                <SelectTrigger id="maritalStatus" className="font-tamil border-maroon-light focus:border-golden">
                  <SelectValue placeholder="தேர்ந்தெடுக்கவும்" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="any" className="font-tamil">Any</SelectItem>
                  {maritalStatusOptions.map((status) => (
                    <SelectItem key={status} value={status} className="font-tamil">
                      {status}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Search Button */}
            <Button
              onClick={handleSearch}
              disabled={searchProfiles.isPending}
              className="w-full bg-maroon hover:bg-maroon-dark text-white font-tamil text-xl py-7 rounded-lg shadow-lg transition-all"
            >
              <Search className="mr-2 h-6 w-6" />
              {searchProfiles.isPending ? 'தேடுகிறது...' : '🔍 தேடு'}
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
