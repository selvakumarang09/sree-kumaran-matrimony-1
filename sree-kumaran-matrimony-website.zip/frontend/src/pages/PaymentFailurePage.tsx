import { useNavigate } from '@tanstack/react-router';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { XCircle } from 'lucide-react';

export default function PaymentFailurePage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-b from-cream via-white to-cream flex items-center justify-center py-12 px-4">
      <Card className="w-full max-w-md border-2 border-maroon shadow-xl">
        <CardHeader className="bg-gradient-to-r from-maroon to-maroon-dark text-white text-center py-8">
          <CardTitle className="text-3xl font-tamil flex items-center justify-center gap-3">
            <XCircle className="h-10 w-10" />
            பணம் செலுத்துதல் தோல்வியடைந்தது
          </CardTitle>
        </CardHeader>
        <CardContent className="p-8 text-center space-y-6">
          <div className="bg-cream p-6 rounded-lg border-2 border-maroon">
            <p className="text-xl text-maroon-dark font-tamil mb-3">
              உங்கள் பணம் செலுத்துதல் தோல்வியடைந்தது அல்லது ரத்து செய்யப்பட்டது.
            </p>
            <p className="text-maroon-dark font-tamil">
              கட்டணம் செயல்படுத்தப்படவில்லை. தயவுசெய்து மீண்டும் முயற்சிக்கவும்.
            </p>
          </div>
          <div className="space-y-3">
            <Button
              onClick={() => navigate({ to: '/pricing' })}
              className="w-full bg-maroon hover:bg-maroon-dark text-white font-tamil text-lg py-6"
            >
              மீண்டும் முயற்சி செய்யுங்கள்
            </Button>
            <Button
              onClick={() => navigate({ to: '/' })}
              variant="outline"
              className="w-full font-tamil text-lg py-6 border-2 border-maroon text-maroon hover:bg-cream"
            >
              முகப்புக்கு திரும்பு
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
