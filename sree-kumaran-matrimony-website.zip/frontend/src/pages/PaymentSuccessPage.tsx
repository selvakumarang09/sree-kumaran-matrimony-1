import { useNavigate } from '@tanstack/react-router';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { CheckCircle } from 'lucide-react';

export default function PaymentSuccessPage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-b from-cream via-white to-cream flex items-center justify-center py-12 px-4">
      <Card className="w-full max-w-md border-2 border-golden shadow-xl">
        <CardHeader className="bg-gradient-to-r from-maroon to-maroon-dark text-white text-center py-8">
          <CardTitle className="text-3xl font-tamil flex items-center justify-center gap-3">
            <CheckCircle className="h-10 w-10" />
            பணம் செலுத்துதல் வெற்றிகரமாக முடிந்தது!
          </CardTitle>
        </CardHeader>
        <CardContent className="p-8 text-center space-y-6">
          <div className="bg-cream p-6 rounded-lg border-2 border-golden">
            <p className="text-xl text-maroon font-tamil font-semibold mb-3">
              உங்கள் பிரீமியம் கணக்கு செயல்படுத்தப்பட்டது
            </p>
            <p className="text-maroon-dark font-tamil">
              நன்றி! உங்கள் பணம் செலுத்துதல் வெற்றிகரமாக முடிந்தது. இப்போது நீங்கள் அனைத்து பிரீமியம் அம்சங்களையும் பயன்படுத்தலாம்.
            </p>
          </div>
          <div className="space-y-3">
            <Button
              onClick={() => navigate({ to: '/register' })}
              className="w-full bg-maroon hover:bg-maroon-dark text-white font-tamil text-lg py-6"
            >
              சுயவிவரத்தை பதிவு செய்யுங்கள்
            </Button>
            <Button
              onClick={() => navigate({ to: '/search' })}
              variant="outline"
              className="w-full font-tamil text-lg py-6 border-2 border-maroon text-maroon hover:bg-cream"
            >
              தேடலுக்கு செல்லுங்கள்
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
