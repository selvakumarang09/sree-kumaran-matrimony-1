import { useNavigate } from '@tanstack/react-router';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Check } from 'lucide-react';
import { SiFacebook, SiX, SiInstagram, SiYoutube } from 'react-icons/si';

export default function PricingPage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-b from-cream via-white to-cream">
      {/* Pricing Header */}
      <section className="py-12 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold text-maroon mb-4 font-tamil">விலை திட்டங்கள்</h1>
            <p className="text-xl text-maroon-dark font-tamil">உங்களுக்கு ஏற்ற திட்டத்தை தேர்வு செய்து, உங்கள் வாழ்க்கைத் துணையை கண்டறியுங்கள்</p>
          </div>

          {/* Pricing Cards */}
          <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto mb-16">
            {/* Free Plan */}
            <Card className="border-2 border-maroon shadow-xl hover:shadow-2xl transition-shadow">
              <CardHeader className="bg-gradient-to-r from-maroon-light to-maroon text-white text-center py-8">
                <CardTitle className="text-3xl md:text-4xl font-tamil mb-2">இலவசம்</CardTitle>
                <CardDescription className="text-cream text-lg font-tamil">
                  சுயவிவரங்களை பார்க்க
                </CardDescription>
              </CardHeader>
              <CardContent className="p-8">
                <ul className="space-y-4">
                  <li className="flex items-start font-tamil text-maroon-dark text-lg">
                    <Check className="h-6 w-6 text-golden mr-3 flex-shrink-0 mt-1" />
                    <span>சுயவிவரங்களை பார்க்கலாம்</span>
                  </li>
                  <li className="flex items-start font-tamil text-maroon-dark text-lg">
                    <Check className="h-6 w-6 text-golden mr-3 flex-shrink-0 mt-1" />
                    <span>அடிப்படை தேடல்</span>
                  </li>
                  <li className="flex items-start font-tamil text-maroon-dark text-lg">
                    <Check className="h-6 w-6 text-golden mr-3 flex-shrink-0 mt-1" />
                    <span>வரையறுக்கப்பட்ட அணுகல்</span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            {/* Premium Plan */}
            <Card className="border-2 border-golden shadow-2xl hover:shadow-3xl transition-shadow relative">
              <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                <div className="bg-golden text-maroon-dark font-tamil font-bold px-6 py-2 rounded-full text-lg shadow-lg">
                  பிரபலமான
                </div>
              </div>
              <CardHeader className="bg-gradient-to-r from-golden to-golden-dark text-maroon-dark text-center py-8 mt-4">
                <CardTitle className="text-3xl md:text-4xl font-tamil mb-2">பிரீமியம் ₹999</CardTitle>
                <CardDescription className="text-maroon text-lg font-tamil font-semibold">
                  உங்கள் சுயவிவரத்தை பதிவு செய்ய
                </CardDescription>
              </CardHeader>
              <CardContent className="p-8">
                <div className="text-center mb-8">
                  <span className="text-5xl font-bold text-maroon">₹999</span>
                </div>
                <ul className="space-y-4 mb-8">
                  <li className="flex items-start font-tamil text-maroon-dark text-lg">
                    <Check className="h-6 w-6 text-golden mr-3 flex-shrink-0 mt-1" />
                    <span>உங்கள் சுயவிவரத்தை பதிவு செய்யலாம்</span>
                  </li>
                  <li className="flex items-start font-tamil text-maroon-dark text-lg">
                    <Check className="h-6 w-6 text-golden mr-3 flex-shrink-0 mt-1" />
                    <span>முழு தேடல் வசதி</span>
                  </li>
                  <li className="flex items-start font-tamil text-maroon-dark text-lg">
                    <Check className="h-6 w-6 text-golden mr-3 flex-shrink-0 mt-1" />
                    <span>தொடர்பு விவரங்களை பார்க்கலாம்</span>
                  </li>
                  <li className="flex items-start font-tamil text-maroon-dark text-lg">
                    <Check className="h-6 w-6 text-golden mr-3 flex-shrink-0 mt-1" />
                    <span>புகைப்படங்கள் பதிவேற்றம்</span>
                  </li>
                  <li className="flex items-start font-tamil text-maroon-dark text-lg">
                    <Check className="h-6 w-6 text-golden mr-3 flex-shrink-0 mt-1" />
                    <span>ஜாதகம் பதிவேற்றம்</span>
                  </li>
                </ul>
                <Button
                  onClick={() => navigate({ to: '/payment' })}
                  className="w-full bg-maroon hover:bg-maroon-dark text-white font-tamil text-xl py-7 rounded-lg shadow-lg"
                >
                  இப்போது பணம் செலுத்துங்கள்
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Why Choose Us Section */}
          <div className="text-center mb-12 max-w-4xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold text-maroon mb-6 font-tamil">
              ஏன் எங்களை தேர்வு செய்ய வேண்டும்?
            </h2>
            <p className="text-lg md:text-xl text-maroon-dark font-tamil leading-relaxed">
              ஸ்ரீ குமரன் மேட்ரிமோனி - பாரம்பரிய தமிழ் திருமண சேவை. நம்பகமான, பாதுகாப்பான மற்றும் குடும்ப மதிப்புகளை மதிக்கும் சேவை. உங்கள் வாழ்க்கைத் துணையை கண்டறிய எங்களுடன் இணையுங்கள்.
            </p>
          </div>
        </div>
      </section>

      {/* Footer Section */}
      <footer className="py-12 px-4 bg-gradient-to-b from-cream to-white border-t-2 border-golden">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-3 gap-8">
            {/* About Section */}
            <div>
              <h3 className="text-2xl font-bold text-maroon mb-4 font-tamil">
                ஸ்ரீ குமரன் மேட்ரிமோனி
              </h3>
              <p className="text-maroon-dark font-tamil">
                நம்பகமான மற்றும் பாரம்பரிய திருமண சேவை. உங்கள் வாழ்க்கை துணையை கண்டுபிடிக்க நாங்கள் உதவுகிறோம்.
              </p>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="text-xl font-bold text-maroon mb-4 font-tamil">
                விரைவு இணைப்புகள்
              </h4>
              <ul className="space-y-2">
                <li>
                  <button
                    onClick={() => navigate({ to: '/about' })}
                    className="text-maroon-dark hover:text-maroon font-tamil transition-colors"
                  >
                    எங்களை பற்றி
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => navigate({ to: '/pricing' })}
                    className="text-maroon-dark hover:text-maroon font-tamil transition-colors"
                  >
                    விலை நிர்ணயம்
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => navigate({ to: '/contact' })}
                    className="text-maroon-dark hover:text-maroon font-tamil transition-colors"
                  >
                    தொடர்பு
                  </button>
                </li>
              </ul>
            </div>

            {/* Social Links */}
            <div>
              <h4 className="text-xl font-bold text-maroon mb-4 font-tamil">
                எங்களை பின்தொடரவும்
              </h4>
              <div className="flex gap-4">
                <a
                  href="#"
                  className="bg-maroon p-3 rounded-full hover:bg-maroon-dark transition-colors"
                  aria-label="Facebook"
                >
                  <SiFacebook className="h-5 w-5 text-golden" />
                </a>
                <a
                  href="#"
                  className="bg-maroon p-3 rounded-full hover:bg-maroon-dark transition-colors"
                  aria-label="X (Twitter)"
                >
                  <SiX className="h-5 w-5 text-golden" />
                </a>
                <a
                  href="#"
                  className="bg-maroon p-3 rounded-full hover:bg-maroon-dark transition-colors"
                  aria-label="Instagram"
                >
                  <SiInstagram className="h-5 w-5 text-golden" />
                </a>
                <a
                  href="#"
                  className="bg-maroon p-3 rounded-full hover:bg-maroon-dark transition-colors"
                  aria-label="YouTube"
                >
                  <SiYoutube className="h-5 w-5 text-golden" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
