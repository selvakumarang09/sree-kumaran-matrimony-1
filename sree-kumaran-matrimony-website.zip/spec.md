# Sree Kumaran Matrimony Website

## Overview
A Tamil matrimony web application titled "Sree Kumaran Matrimony Website" centered around the concept of "உறவுகளின் தொடக்கம்" (Beginning of Relationships).

## Design Theme
- Traditional Tamil aesthetic with cream and gold dominant colors
- Maroon-gold accents throughout the application
- Tamil fonts (Noto Sans Tamil) for all text content
- Responsive, mobile-first design across all pages

## Header and Navigation
- Full-width header spanning complete width of all pages
- Display updated Sree Kumaran Matrimony logo with ornate peacock design, golden lotus, and traditional Tamil styling
- Logo should be responsive and maintain proper proportions without cropping or skewing
- Logo centered vertically in header with transparent or cream background blending seamlessly with gold-maroon theme
- Light cream or golden gradient header background
- Complete navigation menu with Tamil labels in maroon-gold themed buttons with rounded corners:
  - முகப்பு (Home) → navigates to `/`
  - தேடல் (Search) → navigates to `/search`
  - பதிவு (Register) → navigates to `/register`
  - விலை நிர்ணயம் (Pricing) → navigates to `/pricing`
  - எங்களை பற்றி (About Us) → navigates to `/about`
  - தொடர்பு (Contact) → navigates to `/contact`
  - உள்நுழைய (Login) → navigates to `/login`
- Navigation buttons positioned with consistent spacing and proper alignment
- Header layout scales gracefully on both desktop and mobile devices with buttons stacked elegantly on mobile screens

## Pages and Functionality

### Home Page
- **Hero section** with traditional maroon-gold-cream color scheme:
  - Main heading: "உங்கள் வாழ்க்கை துணையை கண்டுபிடிக்கவும்"
  - Subheading: "நம்பகமான மற்றும் பாரம்பரிய திருமண சேவை. ஆயிரக்கணக்கான வெற்றிகரமான திருமணங்கள்."
  - Two centered action buttons below the subheading text:
    - **"பதிவு செய்க"** (Register) button linking to `/register` route
    - **"மேம்பட்ட தேடல்"** (Advanced Search) button linking to the existing advanced search functionality based on Matrimony ID
  - Both buttons styled with traditional Tamil maroon-gold-cream theme, consistent with other CTA buttons
  - Buttons centered, responsive, and visually aligned underneath the subheading text

- **Advanced Search by Matrimony ID section** with traditional maroon-gold-cream theme:
  - Section heading: "மேம்பட்ட தேடல்"
  - Subheading: "Matrimony ID மூலம் சுயவிவரம் தேடுங்கள்"
  - Input field labeled "Matrimony ID" with placeholder text "உதாரணம்: SKM00001"
  - Search button labeled "தேடு" with maroon-gold styling
  - Results display area that shows:
    - Profile card with basic details if Matrimony ID is found
    - Tamil error message "சுயவிவரம் கிடைக்கவில்லை" if no matching profile found
    - Link to full profile view if profile is found
  - Traditional Tamil fonts and responsive design

- **Why Choose Us section** titled "ஏன் எங்களை தேர்வு செய்ய வேண்டும்?" with three feature cards:
  - "நம்பகமான சேவை" with description "அனைத்து சுயவிவரங்களும் சரிபார்க்கப்பட்டவை மற்றும் பாதுகாப்பானவை"
  - "பெரிய சமூகம்" with description "ஆயிரக்கணக்கான சுயவிவரங்கள் உங்கள் தேர்வுக்காக காத்திருக்கின்றன"
  - "மேம்பட்ட தேடல்" with description "உங்கள் விருப்பங்களுக்கு ஏற்ற சுயவிவரங்களை எளிதாக கண்டுபிடிக்கவும்"

- **Call-to-action section** with:
  - Main text: "உங்கள் பயணத்தை இன்றே தொடங்குங்கள்"
  - Supporting text: "உங்கள் சரியான வாழ்க்கை துணையை கண்டுபிடிக்க இப்போதே இணையுங்கள்"

- **Footer section** with traditional styling:
  - Title: "ஸ்ரீ குமரன் மேட்ரிமோனி"
  - Description: "நம்பகமான மற்றும் பாரம்பரிய திருமண சேவை. உங்கள் வாழ்க்கை துணையை கண்டுபிடிக்க நாங்கள் உதவுகிறோம்."
  - Quick links section with: "எங்களை பற்றி", "விலை நிர்ணயம்", "தொடர்பு"
  - Social links section labeled "எங்களை பின்தொடரவும்"

- Responsive design with smooth spacing transitions and visual balance across all sections
- Tamil fonts throughout with consistent golden and maroon themed styling

### Login Page (உள்நுழைய)
- Main heading "உள்நுழைய" with traditional maroon-gold-cream theme
- Login form with Tamil labels and traditional styling:
  - "Matrimony ID" input field with Tamil label "Matrimony ID"
  - "கடவுச்சொல்" (Password) input field with password masking
  - "உள்நுழைய" (Login) submit button with maroon-gold theme
- Tamil error messages for authentication failures:
  - "தவறான Matrimony ID அல்லது கடவுச்சொல்" for invalid credentials
  - "அனைத்து புலங்களையும் நிரப்பவும்" for empty fields
- Traditional Tamil fonts (Noto Sans Tamil) throughout
- Responsive design for mobile and desktop
- Success messages in Tamil upon successful authentication
- Redirect to profile or dashboard after successful login

### Register Page (பதிவு)
- Large Tamil heading "பதிவு செய்க"
- Comprehensive registration form with cream, maroon, and gold theme
- Mobile-first responsive layout with proper Tamil fonts and spacing
- Logical grouping of sections with clear separation and alignment

#### Form Sections:
- **Authentication Information**: "கடவுச்சொல்" (Password) field with secure input masking and "கடவுச்சொல் உறுதிப்படுத்தல்" (Confirm Password) field with validation to ensure passwords match
- **Personal Information**: "பெயர்", "பாலினம்", "பிறந்த தேதி", "வயது", "உயரம்", "எடை", "நிறம்" with proper validation and required field checks
- **Location Information**: Static Tamil label text "மாவட்டத்தை தேர்ந்தெடுக்கவும்" (no input field or dropdown), "ஊர்", "சொந்த ஊர்" with working dropdowns for Tamil Nadu districts
- **Caste and Horoscope**: 
  - "ஜாதி" (customizable input with predefined caste options: முதலியார், வன்னியர், செட்டியார், யாதவர், பிராமணர், முக்குலத்தோர் / தேவர், இதர ஜாதிகள் and free text entry)
  - "துணை ஜாதி" (dynamic dropdown that filters based on selected caste with hierarchical mapping):
    - முதலியார் → முதலியார், செங்குந்தர் / கைக்கோளர், பிள்ளை, அகமுடையார், தொண்டைமண்டல வேளாளர், சைவ வேளாளர், துளுவ வேளாளர், வேளாளர், இசை வேளாளர்
    - வன்னியர் → வன்னியர், வன்னிய கவுண்டர், படையாச்சி, வன்னியகுல க்ஷத்திரியர்
    - செட்டியார் → செட்டியார், வாணிய செட்டியார், சோழிய செட்டியார், தெலுங்கு செட்டியார், ஆயிரவைஸ்யா
    - யாதவர் → யாதவர், கொல்லா, கோனார்
    - பிராமணர் → ஐயங்கார், ஐயர், வடமா, தெலுங்கு பிராமின், பிரகச்சரணம், மார்த்தர், கன்னட பிராமின்
    - முக்குலத்தோர் / தேவர் → தேவர் / முக்குலத்தோர், கள்ளர், அகமுடையார், முத்துராஜா / முத்தரையர்
    - இதர ஜாதிகள் → கவுண்டர், நாயுடு, நாடார், விஸ்வகர்மா, கிராமணி, உடையார், போயர், பார்கவகுலம், குலாலர், வன்னார், கருணீகர், ஆதி திராவிடர், அருந்ததியர், Caste No Bar
  - "கோத்திரம்", "ராசி" (customizable input with predefined Tamil Rasi list and free text entry), "நட்சத்திரம்" (customizable input with predefined Tamil star names and free text entry), "பிறந்த நேரம்" (customizable text input allowing free format entry), "பிறந்த இடம்" with proper dropdowns and text inputs
- **Educational and Professional**: "கல்வித் தகுதி", "தொழில்", "மாத வருமானம்" text inputs
- **Family Information**: "தந்தை/உறவினர் பெயர்", "மொபைல் எண்", "சகோதரர்கள்", "சகோதரிகள்" with numeric validation
- **Marriage Status**: "திருமண நிலை" (customizable input with predefined options: திருமணம் ஆகாதவர், விவாகரத்து, விவாகரத்திற்காக காத்திருப்பவர் and free text entry)
- **ஜாதகம் கட்டம் (Jathaga Kattam)**: Two horoscope grids (ராசி கட்டம் & நவாம்சம் கட்டம்), each 4x4 grid with 16 multi-select dropdowns for graha names allowing multiple planet selections per cell, with the central 4 boxes (middle quadrant) merged into a single larger cell spanning two rows and two columns. The merged central area displays centered gold-colored Tamil text labels "ராசி" (for Rasi Kattam) and "நவாம்சம்" (for Navamsam Kattam) maintaining the maroon-gold traditional theme consistent with grid borders and multi-select dropdown styling. All cells except the merged central area display asterisk ("*") symbols instead of numeric labels. Responsive layout (side-by-side on desktop, stacked on mobile), styled with bright green/gold borders and cream background matching traditional horoscope chart appearance, selected graha names displayed inside each box separated by commas. Available graha options include: சூரியன், சந்திரன், செவ்வாய், புதன், குரு, சுக்கிரன், சனி, ராகு, கேது, லக்னம்
- **Life Partner Expectations**: "எதிர்பார்ப்புகள்" textarea
- **File Upload**: "புகைப்படம்" and "ஜாதகம்" file inputs with proper format validation
- **Submit Button**: "பதிவு செய்க" with validation and Tamil error handling

#### Customizable Input Fields:
- ஜாதி, துணை ஜாதி, ராசி, நட்சத்திரம், திருமண நிலை, பிறந்த நேரம் fields use hybrid CreatableSelect-style inputs
- Support both selection from predefined Tamil options and free text entry in Tamil
- Maintain traditional Tamil styling with maroon-gold theme
- All custom values validated and stored in backend profile data
- Tamil placeholder text and validation messages

#### Form Requirements:
- All required fields validated with Tamil error messages
- Password strength validation with Tamil feedback
- Password confirmation matching validation
- Proper error feedback and duplicate submission prevention
- All dropdowns and customizable inputs have non-empty placeholder values
- Traditional Tamil styling with consistent spacing and full responsiveness
- Custom user-entered values properly handled and stored
- Unique Matrimony ID automatically generated (e.g., SKM00001) and displayed to user upon successful registration

### Search Page (தேடல்)
- Centered Tamil heading "தேடல்" with subheading "உங்கள் வாழ்க்கைத் துணையை கண்டறியுங்கள்"
- Prominent section titled "விரைவு தேடல்" with traditional Tamil cream, maroon, and gold design
- Age range numeric inputs with default values "21" and "35" labeled "முதல்" and "வரை"
- Search fields in Tamil:
  - பாலினம் (Gender) with radio buttons (ஆண், பெண்)
  - மாவட்டம் (District) dropdown with "Any" option at top plus Tamil Nadu districts and custom entries
  - ஜாதி (Caste) dropdown with "Any" option plus major caste categories: முதலியார், வன்னியர், செட்டியார், யாதவர், பிராமணர், முக்குலத்தோர் / தேவர், இதர ஜாதிகள் and custom entries
  - துணை ஜாதி (Sub Caste) dynamic dropdown that filters based on selected caste with hierarchical mapping:
    - முதலியார் → முதலியார், செங்குந்தர் / கைக்கோளர், பிள்ளை, அகமுடையார், தொண்டைமண்டல வேளாளர், சைவ வேளாளர், துளுவ வேளாளர், வேளாளர், இசை வேளாளர்
    - வன்னியர் → வன்னியர், வன்னிய கவுண்டர், படையாச்சி, வன்னியகுல க்ஷத்திரியர்
    - செட்டியார் → செட்டியார், வாணிய செட்டியார், சோழிய செட்டியார், தெலுங்கு செட்டியார், ஆயிரவைஸ்யா
    - யாதவர் → யாதவர், கொல்லா, கோனார்
    - பிராமணர் → ஐயங்கார், ஐயர், வடமா, தெலுங்கு பிராமின், பிரகச்சரணம், மார்த்தர், கன்னட பிராமின்
    - முக்குலத்தோர் / தேவர் → தேவர் / முக்குலத்தோர், கள்ளர், அகமுடையார், முத்துராஜா / முத்தரையர்
    - இதர ஜாதிகள் → கவுண்டர், நாயுடு, நாடார், விஸ்வகர்மா, கிராமணி, உடையார், போயர், பார்கவகுலம், குலாலர், வன்னார், கருணீகர், ஆதி திராவிடர், அருந்ததியர், Caste No Bar
  - ராசி (Rasi) dropdown with "Any" option plus Tamil Rasi list and custom entries
  - நட்சத்திரம் (Natchatiram) dropdown with "Any" option plus Tamil star names and custom entries
  - திருமண நிலை (Marital Status) dropdown with "Any" option plus "திருமணம் ஆகாதவர்" and other specified options and custom entries
- Large centered search button labeled "🔍 தேடு" with maroon-gold theme
- Traditional Tamil fonts, maroon–gold–cream theme, full mobile-responsive design with clean centered layout
- No profile results shown on this page

### Profile View Page (சுயவிவரம்)
- Display full profile details in Tamil with traditional theme colors and responsive design
- Show all fields including custom user-entered values: Matrimony ID, பெயர், வயது, உயரம், நிறம், மாவட்டம், ஜாதி/துணை ஜாதி, கோத்திரம், ராசி/நட்சத்திரம், பிறந்த நேரம், பிறந்த இடம், கல்வி, தொழில், வருமானம், சொந்த ஊர், திருமண நிலை
- Visual Tamil section titles and icons for each info group
- ஜாதகம் கட்டம் (Rasi Kattam + Navamsam Kattam) display in 4x4 grid format with merged central 4 boxes showing centered gold-colored Tamil text labels "ராசி" (for Rasi Kattam) and "நவாம்சம்" (for Navamsam Kattam) maintaining the maroon-gold traditional theme. All cells except the merged central area display asterisk ("*") symbols instead of numeric labels. Multiple graha names per cell separated by commas in surrounding boxes, side-by-side on wide screens, stacked on mobile
- Family details (தந்தை/உறவினர் பெயர், மொபைல் எண், சகோதரர்கள், சகோதரிகள்)
- Life Partner Expectations section (எதிர்பார்ப்புகள்)
- Display uploaded profile picture (🖼️ புகைப்படம்) and horoscope attachment (📜 ஜாதகம் இணைப்பு)
- "திருத்து சுயவிவரம்" (Edit Profile) button visible only to profile owner
- Guest users view-only access
- Cream, gold, maroon colors with Noto Sans Tamil font and responsive layout

### Profile Edit Page (சுயவிவரம் திருத்து)
- Comprehensive profile editing form with same structure as registration page
- Pre-populated with existing user data including custom field values
- **Location Information** section with static Tamil label text "மாவட்டத்தை தேர்ந்தெடுக்கவும்" (no input field or dropdown)
- All customizable fields (ஜாதி, துணை ஜாதி, ராசி, நட்சத்திரம், திருமண நிலை, பிறந்த நேரம்) maintain CreatableSelect functionality
- **துணை ஜாதி** field includes dynamic filtering based on selected caste with hierarchical mapping:
  - முதலியார் → முதலியார், செங்குந்தர் / கைக்கோளர், பிள்ளை, அகமுடையார், தொண்டைமண்டல வேளாளர், சைவ வேளாளர், துளுவ வேளாளர், வேளாளர், இசை வேளாளர்
  - வன்னியர் → வன்னியர், வன்னிய கவுண்டர், படையாச்சி, வன்னியகுல க்ஷத்திரியர்
  - செட்டியார் → செட்டியார், வாணிய செட்டியார், சோழிய செட்டியார், தெலுங்கு செட்டியார், ஆயிரவைஸ்யா
  - யாதவர் → யாதவர், கொல்லா, கோனார்
  - பிராமணர் → ஐயங்கார், ஐயர், வடமா, தெலுங்கு பிராமின், பிரகச்சரணம், மார்த்தர், கன்னட பிராமின்
  - முக்குலத்தோர் / தேவர் → தேவர் / முக்குலத்தோர், கள்ளர், அகமுடையார், முத்துராஜா / முத்தரையர்
  - இதர ஜாதிகள் → கவுண்டர், நாயுடு, நாடார், விஸ்வகர்மா, கிராமணி, உடையார், போயர், பார்கவகுலம், குலாலர், வன்னார், கருணீகர், ஆதி திராவிடர், அருந்ததியர், Caste No Bar
- **ஜாதகம் கட்டம் (Jathaga Kattam)**: Two horoscope grids (ராசி கட்டம் & நவாம்சம் கட்டம்), each 4x4 grid with 16 multi-select dropdowns for graha names allowing multiple planet selections per cell, with the central 4 boxes (middle quadrant) merged into a single larger cell spanning two rows and two columns displaying centered gold-colored Tamil text labels "ராசி" (for Rasi Kattam) and "நவாம்சம்" (for Navamsam Kattam) maintaining the maroon-gold traditional theme. All cells except the merged central area display asterisk ("*") symbols instead of numeric labels. Available graha options include: சூரியன், சந்திரன், செவ்வாய், புதன், குரு, சுக்கிரன், சனி, ராகு, கேது, லக்னம்
- Traditional maroon-gold-cream styling with mobile responsiveness
- Validation and storage of both predefined and custom user inputs
- Tamil interface with proper error handling and success messages

### Pricing Page (விலை திட்டங்கள்)
- Main heading "விலை திட்டங்கள்" with subtitle "உங்களுக்கு ஏற்ற திட்டத்தை தேர்வு செய்து, உங்கள் வாழ்க்கைத் துணையை கண்டறியுங்கள்"
- Two pricing cards with traditional maroon-gold-cream theme:
  - **இலவசம் (Free) Plan Card**:
    - Heading: "இலவசம்"
    - Description: "சுயவிவரங்களை பார்க்க"
    - Features listed: "சுயவிவரங்களை பார்க்கலாம்", "அடிப்படை தேடல்", "வரையறுக்கப்பட்ட அணுகல்"
  - **பிரீமியம் ₹999 (Premium) Plan Card**:
    - "பிரபலமான" label displayed above the card
    - Title: "பிரீமியம் ₹999"
    - Subheading: "உங்கள் சுயவிவரத்தை பதிவு செய்ய"
    - Price: "₹999"
    - Features listed: "உங்கள் சுயவிவரத்தை பதிவு செய்யலாம்", "முழு தேடல் வசதி", "தொடர்பு விவரங்களை பார்க்கலாம்", "புகைப்படங்கள் பதிவேற்றம்", "ஜாதகம் பதிவேற்றம்"
    - Main button: "இப்போது பணம் செலுத்துங்கள்" with maroon-gold theme linking to payment page
- **Why Choose Us section** titled "ஏன் எங்களை தேர்வு செய்ய வேண்டும்?" with Tamil text: "ஸ்ரீ குமரன் மேட்ரிமோனி - பாரம்பரிய தமிழ் திருமண சேவை. நம்பகமான, பாதுகாப்பான மற்றும் குடும்ப மதிப்புகளை மதிக்கும் சேவை. உங்கள் வாழ்க்கைத் துணையை கண்டறிய எங்களுடன் இணையுங்கள்."
- **Footer section** with traditional styling:
  - Title: "ஸ்ரீ குமரன் மேட்ரிமோனி"
  - Description: "நம்பகமான மற்றும் பாரம்பரிய திருமண சேவை. உங்கள் வாழ்க்கை துணையை கண்டுபிடிக்க நாங்கள் உதவுகிறோம்."
  - Section "விரைவு இணைப்புகள்" with links: "எங்களை பற்றி", "விலை நிர்ணயம்", "தொடர்பு"
  - Social links section labeled "எங்களை பின்தொடரவும்"
- Fully responsive layout with traditional Tamil fonts and maroon-gold-cream color scheme

### Payment Page (பணம் செலுத்தல்)
- Main heading "பணம் செலுத்தல்" with traditional maroon-gold-cream theme
- Subheading "பிரீமியம் திட்டத்திற்கு மேம்படுத்தி முழு அம்சங்களை பெறுங்கள்"
- Tamil fonts (Noto Sans Tamil) throughout the page
- Responsive design for mobile, tablet, and desktop views

#### Payment Sections:
- **இலவச திட்டம் (Free Plan) Section**:
  - Title: "இலவச திட்டம்"
  - Description: "சுயவிவரங்களை பார்க்கலாம்"
  - Disabled button labeled "இலவசம்" with muted styling

- **பிரீமியம் திட்டம் (Premium Plan) Section**:
  - Title: "பிரீமியம் திட்டம் ₹999"
  - Comprehensive description: "உங்கள் சுயவிவரத்தை பதிவு செய்யலாம், முழு தேடல் வசதி, தொடர்பு விவரங்கள் பார்க்கலாம், புகைப்படம் மற்றும் ஜாதகம் பதிவேற்றம்"
  - Visible Tamil note: "பணம் செலுத்தல் புதிய சாளரத்தில் திறக்கும்" (Payment opens in a new window)
  - Large gold-themed button labeled "பணம் செலுத்துங்கள்" (Pay Now) with gold animation hover effect
  - Button opens Stripe checkout session in a new browser window/tab using window.open functionality
  - On payment success: redirect to `/payment-success` page
  - On payment failure: redirect to `/payment-failure` page

#### Footer Section:
- Title: "ஸ்ரீ குமரன் மேட்ரிமோனி"
- Description: "நம்பகமான மற்றும் பாரம்பரிய திருமண சேவை. உங்கள் வாழ்க்கை துணையை கண்டுபிடிக்க நாங்கள் உதவுகிறோம்."
- Quick links section with: "எங்களை பற்றி", "விலை நிர்ணயம்", "தொடர்பு"
- Social links section labeled "எங்களை பின்தொடரவும்"

### Payment Gateway
- Stripe payment integration for premium plan (₹999) processing
- Tamil interface with traditional maroon-gold-cream theme
- Payment form with Tamil labels:
  - "பணம் செலுத்துதல்" heading
  - "பிரீமியம் திட்டம் - ₹999" plan details
  - "கார்டு விவரங்கள்" card input section
  - "பணம் செலுத்துங்கள்" submit button
- Secure payment processing with validation
- Loading states with Tamil text "செயலாக்கப்படுகிறது..."
- Error handling with Tamil error messages

### Payment Success Page
- Tamil heading "பணம் செலுத்துதல் வெற்றிகரமாக முடிந்தது!"
- Success message in Tamil with traditional styling
- "உங்கள் பிரீமியம் கணக்கு செயல்படுத்தப்பட்டது" confirmation
- "சுயவிவரத்திற்கு செல்லுங்கள்" button linking to profile
- Traditional maroon-gold-cream theme with responsive design

### Payment Failure Page
- Tamil heading "பணம் செலுத்துதல் தோல்வியடைந்தது"
- Error message in Tamil explaining the failure
- "மீண்டும் முயற்சி செய்யுங்கள்" button to retry payment
- "விலை திட்டங்களுக்கு திரும்பு" button linking back to pricing
- Traditional maroon-gold-cream theme with responsive design

### Contact Page (தொடர்பு)
- Main heading "எங்களை தொடர்பு கொள்ளுங்கள்" with traditional maroon-gold-cream theme
- Tamil fonts (Noto Sans Tamil) throughout the page
- Responsive design for mobile and desktop views

#### Content Sections:
- **Introduction section** with Tamil content:
  - "உங்கள் கேள்விகளுக்கு நாங்கள் உதவ தயாராக உள்ளோம்"
  - Paragraphs describing Sree Kumaran Matrimony service and contact encouragement
  - "உறவுகளின் தொடக்கம் - நம்பிக்கையுடன், பாரம்பரியத்துடன்"

- **Contact Information section**:
  - "தொடர்பு தகவல்" heading
  - "மின்னஞ்சல் 📧 sreekumaranmatrimony@gmail.com"

- **Promise section**:
  - "எங்கள் வாக்குறுதி" heading
  - Final paragraph about user data safety and traditional service values

#### Footer Section:
- Title: "ஸ்ரீ குமரன் மேட்ரிமோனி"
- Description: "நம்பகமான மற்றும் பாரம்பரிய திருமண சேவை. உங்கள் வாழ்க்கை துணையை கண்டுபிடிக்க நாங்கள் உதவுகிறோம்."
- Quick links section with: "எங்களை பற்றி", "விலை நிர்ணயம்", "தொடர்பு"
- Social links section labeled "எங்களை பின்தொடரவும்"

### About Page (எங்களை பற்றி)
- Main heading "எங்களை பற்றி" with tagline "உறவுகளின் தொடக்கம்" at the top
- Traditional maroon-gold-cream theme with Tamil fonts (Noto Sans Tamil)
- Responsive design across mobile and desktop views

#### Content Sections:
- **எங்கள் நோக்கம்** section with comprehensive Tamil content including multiple paragraphs with proper spacing and paragraph alignment
- **நம்பிக்கை** subsection with Tamil title and description
- **குடும்ப மதிப்புகள்** subsection with Tamil title and description  
- **எளிமை** subsection with Tamil title and description
- **பாரம்பரியம்** subsection with Tamil title and description
- **ஏன் எங்களை தேர்வு செய்ய வேண்டும்?** subsection with Tamil title and description

#### Footer Section:
- Title: "ஸ்ரீ குமரன் மேட்ரிமோனி"
- Description: "நம்பகமான மற்றும் பாரம்பரிய திருமண சேவை. உங்கள் வாழ்க்கை துணையை கண்டுபிடிக்க நாங்கள் உதவுகிறோம்."
- Quick links section with: "எங்களை பற்றி", "விலை நிர்ணயம்", "தொடர்பு"
- Social links section labeled "எங்களை பின்தொடரவும்"

### Admin Analytics Page
- Interactive analytics dashboard accessible only to admin users
- Administrative controls for managing the platform

#### Interactive Admin Analytics Dashboard
- Restricted access to admin users only with Tamil error messages for unauthorized access
- Animated summary cards with smooth fade-in animations displaying:
  - மொத்த பதிவு செய்யப்பட்ட பயனர்கள் (Total registered users)
  - செயலில் உள்ள பயனர்கள் (Active users)
  - இந்த மாதம் உருவாக்கப்பட்ட சுயவிவரங்கள் (Profiles created this month)
- React chart components with animations for:
  - பாலின விநியோகம் (Gender distribution) — animated pie chart showing ஆண் vs பெண்
  - திருமண நிலை பிரிவு (Marital status breakdown) — animated bar chart for திருமணம் ஆகாதவர், விவாகரத்து, விவாகரத்திற்காக காத்திருப்பவர் and custom entries
  - உறுப்பினர் எண்ணிக்கையின் அடிப்படையில் முதன்மை மாவட்டங்கள் (Top districts by member count) — animated bar chart including custom district entries
- Hover tooltips with Tamil details and smooth transitions
- Auto-refresh every 30 seconds using React Query for real-time data updates
- Full Tamil maroon–gold–cream theme with traditional Tamil fonts
- Responsive design across all devices

## Deployment and Export
- Complete application packaging into a single ZIP archive for website deployment
- Include all frontend and backend code, assets, and configuration files
- Deployment-ready structure with proper build scripts and dependencies
- Export functionality for complete application launch and hosting

## Backend Data Storage
- User profiles with comprehensive matrimony details including personal information, location, caste, sub-caste with hierarchical mapping, horoscope data, education, profession, family details, marriage status, horoscope grids (ராசி கட்டம் & நவாம்சம் கட்டம்) with 4x4 grid layout including merged center cell with multiple graha selections per cell (including லக்னம்), life partner expectations, and uploaded files
- Unique Matrimony ID generation and storage (e.g., SKM00001, SKM00002, etc.)
- Secure password storage with SHA256 hashing mechanism
- Custom user-entered values for ஜாதி, துணை ஜாதி, ராசி, நட்சத்திரம், திருமண நிலை, பிறந்த நேரம் fields stored as text data
- Caste-subcaste hierarchical mapping data for dynamic filtering
- User authentication data with Matrimony ID and hashed password mapping
- Subscription plans and pricing information
- Payment transaction records with Stripe integration
- Premium subscription status and expiry dates
- Contact form submissions
- User authentication data with admin role identification
- Search preferences and match history
- File storage for profile photos and horoscope documents
- Analytics data for dashboard metrics

## Backend Operations
- Matrimony ID-based authentication system with password verification
- Unique Matrimony ID generation (sequential numbering: SKM00001, SKM00002, etc.)
- Secure password hashing using SHA256 before storage
- User registration with comprehensive profile data processing including multi-select horoscope graha data for 4x4 grid layout with merged center cell and custom field values (including லக்னம் graha option)
- Login authentication using Matrimony ID and password verification against hashed passwords
- Validation and storage of custom user-entered values for specified fields
- Caste-subcaste hierarchical mapping validation and filtering logic
- File upload handling for photos and horoscope documents
- User authentication and profile management with admin role verification
- Profile creation and updates with validation for multi-select horoscope data in 4x4 grid format with merged center cell and custom field entries (including லக்னம் graha option)
- Search functionality with filtering by gender, age range, district (including custom entries), caste (including custom entries), sub-caste with hierarchical filtering (including custom entries), rasi (including custom entries), natchatiram (including custom entries), and marital status (including custom entries)
- Profile retrieval for detailed view with multi-graha horoscope display in 4x4 grid format with merged center cell and custom field values
- **Advanced search by Matrimony ID** with profile lookup functionality that returns matching user profile data or null if not found
- Stripe payment processing for premium subscriptions
- Payment success and failure handling with subscription activation
- Premium subscription management and validation
- Contact form processing
- Admin analytics and reporting with real-time data aggregation including custom field data
- Analytics API endpoints for dashboard metrics:
  - Total registered users count
  - Active/logged-in users tracking
  - Monthly profile creation statistics
  - Gender distribution calculations
  - Marital status breakdown analysis including custom entries
  - District-wise member count aggregation including custom district entries
- Data validation for horoscope grids with 4x4 layout including merged center cell with multiple graha selections (including லக்னம்), personal information, and custom field entries
- Session management and user role-based access control
- Application packaging and export functionality for deployment

## Content Language
All application content, labels, and text in Tamil language.
